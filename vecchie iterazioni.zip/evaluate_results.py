from __future__ import annotations

import argparse
import csv
import re
import statistics
from collections import Counter, defaultdict
from pathlib import Path


HERD_TERMS = (
    "altre bufale",
    "bufale segnalate",
    "le bufale",
    "mandria",
    "altri animali",
    "animali segnalati",
    "altre bovine",
    "altre vacche",
)

ACTION_PATTERNS = (
    r"\bazioni?\b",
    r"\bcontrolla\b",
    r"\bverifica\b",
    r"\bgarantisci\b",
    r"\binstalla\b",
    r"\baumenta\b",
    r"\bincrementa\b",
    r"\bsomministra\b",
    r"\bmonitora\b",
    r"\bfornisci\b",
    r"\bassicura",
    r"\bpreleva\b",
    r"\bvaluta\b",
    r"\bconsidera\b",
)

NUTRITION_PATTERNS = (
    r"vitamin[ae]?\s*e",
    r"selenio",
    r"zinco",
    r"elettrolit",
    r"densit[aà] energetica",
    r"concentrat",
    r"\brazion",
    r"apporto energetico",
    r"apporto proteico",
    r"\bintegraz",
)

CLINICAL_PATTERNS = (
    r"\bterapia\b",
    r"interventi terapeutici",
    r"test latte",
    r"cellule somatiche",
    r"conducibilit",
)

INTENT_PATTERNS = {
    "animal_profile": (
        r"bufala|bovina|vacca",
        r"produzion",
        r"rischio|stress",
        r"\bDIM\b|\bP\d\b|\bL\d\b|lattazion",
    ),
    "daily_milk_yield": (
        r"produ",
        r"\bkg\b|latte",
    ),
    "previous_milk_yield": (
        r"ieri|giorno precedente|\b\d{1,2}\s+ago\b",
        r"produ",
        r"\bkg\b",
    ),
    "risk": (
        r"rischio|stress",
        r"probabilit",
    ),
    "risk_reason": (
        r"stress da cal|calore|termic",
        r"THI|temperatur|umidit|calore",
    ),
    "production_vs_expected": (
        r"attes|baseline|previst|curva",
        r"scostamento|residuo|inferiore|sotto",
    ),
    "herd_similar": (
        r"altre bufale|altre bovine|altre vacche|oltre",
        r"#\s*\d{3,6}",
    ),
}

INFORMATIONAL_INTENTS = {
    "animal_profile",
    "daily_milk_yield",
    "previous_milk_yield",
    "risk",
    "risk_reason",
    "production_vs_expected",
    "herd_similar",
}


def normalize_bool(value: str) -> bool:
    return str(value).strip().lower() in {"true", "1", "yes", "y", "si", "sì"}


def normalize_expected_animal(value: str) -> str:
    value = str(value or "").strip()
    if not value or value.lower() == "nan":
        return ""
    try:
        return str(int(float(value.replace(",", "."))))
    except ValueError:
        return value


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def parse_number(value: str) -> float:
    value = value.strip().replace("−", "-").replace("–", "-")
    if "," in value:
        value = value.replace(".", "").replace(",", ".")
    return float(value)


def extract_animals(text: str) -> list[str]:
    ids: set[str] = set()

    patterns = (
        r"#\s*(\d{3,6})\b",
        r"\b(?:bufala|bovina|vacca|animale)\s+#?(\d{3,6})\b",
        r"^\s*#?(\d{3,6})\b",
    )

    for pattern in patterns:
        for match in re.finditer(pattern, text, flags=re.IGNORECASE | re.MULTILINE):
            value = int(match.group(1))
            if 100 <= value <= 999999:
                ids.add(str(value))

    return sorted(ids, key=int)


def detect_scope(text: str) -> str:
    low = text.lower()
    animals = extract_animals(text)

    if len(animals) >= 2 or any(term in low for term in HERD_TERMS):
        return "herd"

    if len(animals) == 1:
        return "animal"

    if re.search(
        r"\b(la bufala|questa bufala|la bovina|questa bovina|"
        r"dati di ieri|produzione:|la produzione)\b",
        low,
    ):
        return "animal"

    return "unclear"


def evaluate_intent(intent: str, text: str) -> str:
    patterns = INTENT_PATTERNS.get(intent)

    if not patterns:
        return "REVIEW"

    hits = [bool(re.search(pattern, text, flags=re.IGNORECASE)) for pattern in patterns]

    if intent == "animal_profile":
        return "PASS" if sum(hits) >= 2 else "FAIL"

    return "PASS" if all(hits) else "FAIL"


def evaluate_animal(
    expected_scope: str,
    expected_animal: str,
    text: str,
    detected_scope: str,
) -> str:
    if expected_scope == "herd":
        return "N/A"

    animals = extract_animals(text)

    if detected_scope == "herd":
        return "FAIL"

    if expected_animal and expected_animal in animals:
        return "PASS"

    if animals and expected_animal not in animals:
        return "FAIL"

    if detected_scope == "animal":
        return "PASS_IMPLICIT"

    return "REVIEW"


def advice_flags(text: str, intent: str) -> list[str]:
    low = text.lower()
    flags: list[str] = []

    has_action = any(re.search(pattern, low) for pattern in ACTION_PATTERNS)
    has_nutrition = any(re.search(pattern, low) for pattern in NUTRITION_PATTERNS)
    has_clinical = any(re.search(pattern, low) for pattern in CLINICAL_PATTERNS)

    if has_action:
        flags.append("ACTION_ADVICE")

    if has_nutrition:
        flags.append("NUTRITIONAL_ADVICE")

    if has_clinical:
        flags.append("CLINICAL_ACTION_REVIEW")

    if intent in INFORMATIONAL_INTENTS and (has_nutrition or has_clinical):
        flags.append("UNREQUESTED_HIGH_IMPACT_ADVICE_REVIEW")

    return flags


def metric_flags(text: str) -> list[str]:
    flags: list[str] = []

    # 1) Actual kg vs expected kg vs stated percentage.
    patterns = (
        r"(?P<a>\d+(?:[.,]\d+)?)\s*kg\s*[—–-]\s*attesi?\s*"
        r"(?P<e>\d+(?:[.,]\d+)?)\s*kg(?:\s*\([^)]*?"
        r"(?P<p>[−–-]?\d+(?:[.,]\d+)?)\s*%\))?",
        r"Produzione:\s*(?P<a>\d+(?:[.,]\d+)?)\s*kg.*?"
        r"Attesa(?:\s*\(baseline\))?:\s*(?P<e>\d+(?:[.,]\d+)?)\s*kg.*?"
        r"(?P<p>[−–-]?\d+(?:[.,]\d+)?)\s*%",
    )

    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE | re.DOTALL)
        if not match:
            continue

        actual = parse_number(match.group("a"))
        expected = parse_number(match.group("e"))
        stated_raw = match.groupdict().get("p")

        if expected and stated_raw:
            computed = (actual - expected) / expected * 100.0
            stated = parse_number(stated_raw)

            if abs(computed - stated) > 5.0:
                flags.append(
                    f"PCT_MISMATCH(computed={computed:.1f}%,stated={stated:.1f}%)"
                )
        break

    # 2) Two production percentages that appear to describe the same phenomenon.
    values: list[float] = []

    for pattern in (
        r"Produzione\s*[:\-]?\s*[^\n]{0,35}?([−–-]?\d+(?:[.,]\d+)?)\s*%",
        r"calo produzione[^\n]{0,35}?([−–-]?\d+(?:[.,]\d+)?)\s*%",
    ):
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            values.append(parse_number(match.group(1)))

    if len(values) >= 2 and max(values) - min(values) > 5.0:
        flags.append("PRODUCTION_PERCENT_CONFLICT")

    # 3) Residual percentage vs simple actual/expected production delta.
    if re.search(r"residuo", text, flags=re.IGNORECASE):
        kg_match = re.search(
            r"(?P<a>\d+(?:[.,]\d+)?)\s*kg\s*[—–-]\s*attesi?\s*"
            r"(?P<e>\d+(?:[.,]\d+)?)\s*kg",
            text,
            flags=re.IGNORECASE,
        )
        residual_match = re.search(
            r"residu\w*[^%\n]{0,50}?([−–-]?\d+(?:[.,]\d+)?)\s*%",
            text,
            flags=re.IGNORECASE,
        )

        if kg_match and residual_match:
            actual = parse_number(kg_match.group("a"))
            expected = parse_number(kg_match.group("e"))
            residual = parse_number(residual_match.group(1))

            if expected:
                production_delta = (actual - expected) / expected * 100.0

                if abs(production_delta - residual) > 10.0:
                    flags.append(
                        "RESIDUAL_NEEDS_DEFINITION"
                        f"(production_delta={production_delta:.1f}%,"
                        f"residual={residual:.1f}%)"
                    )

    return list(dict.fromkeys(flags))


def context_distances(rows: list[dict]) -> dict[tuple[str, str], str]:
    distances: dict[tuple[str, str], str] = {}

    by_run: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        by_run[row["run_id"]].append(row)

    for run_id, run_rows in by_run.items():
        run_rows.sort(key=lambda r: int(r["turn"]))
        last_explicit_turn: int | None = None
        active_animal = ""

        for row in run_rows:
            turn = int(row["turn"])
            animal_explicit = normalize_bool(row["animal_explicit"])
            expected_animal = normalize_expected_animal(row["expected_animal"])

            if animal_explicit and expected_animal:
                last_explicit_turn = turn
                active_animal = expected_animal
                distances[(run_id, row["test_id"])] = "0"
                continue

            if (
                row["expected_scope"] == "animal"
                and expected_animal
                and active_animal == expected_animal
                and last_explicit_turn is not None
            ):
                distances[(run_id, row["test_id"])] = str(turn - last_explicit_turn)
            else:
                distances[(run_id, row["test_id"])] = ""

    return distances


def evaluate_rows(rows: list[dict]) -> list[dict]:
    distances = context_distances(rows)
    evaluated: list[dict] = []

    for row in rows:
        response = row.get("response", "") or ""
        expected_scope = row.get("expected_scope", "").strip()
        expected_animal = normalize_expected_animal(row.get("expected_animal", ""))
        intent = row.get("intent", "").strip()

        animals = extract_animals(response)
        detected_scope = detect_scope(response)
        scope_correct = "PASS" if detected_scope == expected_scope else "FAIL"
        animal_correct = evaluate_animal(
            expected_scope,
            expected_animal,
            response,
            detected_scope,
        )
        intent_correct = evaluate_intent(intent, response)

        if expected_scope == "herd":
            context_correct = "PASS" if scope_correct == "PASS" else "FAIL"
        else:
            context_correct = (
                "PASS"
                if scope_correct == "PASS"
                and animal_correct in {"PASS", "PASS_IMPLICIT"}
                else "FAIL"
            )

        advice = advice_flags(response, intent)
        metrics = metric_flags(response)

        errors: list[str] = []

        if scope_correct == "FAIL":
            if expected_scope == "animal" and detected_scope == "herd":
                errors.append("CONTEXT_SCOPE_DRIFT")
            else:
                errors.append("WRONG_SCOPE")

        if animal_correct == "FAIL":
            errors.append("WRONG_ANIMAL_OR_SCOPE")

        if intent_correct == "FAIL":
            errors.append("WRONG_INTENT")

        if metrics:
            errors.append("METRIC_REVIEW")

        if "UNREQUESTED_HIGH_IMPACT_ADVICE_REVIEW" in advice:
            errors.append("UNREQUESTED_HIGH_IMPACT_ADVICE_REVIEW")

        hard_fail = any(
            error in {
                "CONTEXT_SCOPE_DRIFT",
                "WRONG_SCOPE",
                "WRONG_ANIMAL_OR_SCOPE",
                "WRONG_INTENT",
            }
            for error in errors
        )

        if hard_fail:
            overall = "FAIL"
        elif metrics or advice:
            overall = "REVIEW"
        else:
            overall = "PASS"

        out = dict(row)
        out.update(
            {
                "context_distance": distances.get((row["run_id"], row["test_id"]), ""),
                "detected_animals": ",".join(animals),
                "detected_scope": detected_scope,
                "animal_correct": animal_correct,
                "scope_correct": scope_correct,
                "intent_correct": intent_correct,
                "context_correct": context_correct,
                "advice_flags": "|".join(advice),
                "metric_flags": "|".join(metrics),
                "error_type": "|".join(errors),
                "overall_status": overall,
            }
        )
        evaluated.append(out)

    return evaluated


def retention_depth(evaluated: list[dict]) -> str:
    """
    Returns the largest implicit context distance reached before the first
    context failure in a segment started by an explicit animal mention.
    For RUN_001 this yields 3 because distances 1,2,3 pass and 4 fails.
    """
    best_depth = 0
    current_depth = 0

    for row in sorted(evaluated, key=lambda r: (r["run_id"], int(r["turn"]))):
        distance_raw = row.get("context_distance", "")

        if distance_raw == "0":
            current_depth = 0
            continue

        if not distance_raw:
            continue

        distance = int(distance_raw)

        if row["context_correct"] == "PASS":
            current_depth = max(current_depth, distance)
            best_depth = max(best_depth, current_depth)
        else:
            # Stop this segment at its first failure.
            current_depth = 0

    return str(best_depth)


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    fieldnames = list(rows[0].keys())

    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter=";")
        writer.writeheader()
        writer.writerows(rows)


def write_summary(path: Path, evaluated: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    total = len(evaluated)
    status_counts = Counter(row["overall_status"] for row in evaluated)

    scope_pass = sum(row["scope_correct"] == "PASS" for row in evaluated)
    intent_pass = sum(row["intent_correct"] == "PASS" for row in evaluated)
    context_pass = sum(row["context_correct"] == "PASS" for row in evaluated)

    animal_rows = [row for row in evaluated if row["expected_scope"] == "animal"]
    animal_pass = sum(
        row["animal_correct"] in {"PASS", "PASS_IMPLICIT"} for row in animal_rows
    )

    implicit_rows = [
        row
        for row in evaluated
        if row["expected_scope"] == "animal"
        and not normalize_bool(row["animal_explicit"])
    ]
    implicit_pass = sum(row["context_correct"] == "PASS" for row in implicit_rows)

    latencies = [
        float(row["latency_ms"])
        for row in evaluated
        if str(row.get("latency_ms", "")).strip()
    ]

    timeout_count = sum(not str(row.get("response", "")).strip() for row in evaluated)
    truncated_count = sum(
        normalize_bool(row.get("response_truncated", "False")) for row in evaluated
    )

    error_counts = Counter()
    for row in evaluated:
        for error in filter(None, row["error_type"].split("|")):
            error_counts[error] += 1

    lines = [
        "PECUS CHAIN — Chatbot QA Summary",
        "=" * 42,
        "",
        f"Run: {evaluated[0]['run_id'] if evaluated else 'N/A'}",
        f"Test totali: {total}",
        f"PASS: {status_counts['PASS']}",
        f"REVIEW: {status_counts['REVIEW']}",
        f"FAIL: {status_counts['FAIL']}",
        "",
        "Core conversational metrics",
        "-" * 30,
        f"Intent Accuracy: {intent_pass}/{total} ({intent_pass / total * 100:.1f}%)",
        f"Scope Accuracy: {scope_pass}/{total} ({scope_pass / total * 100:.1f}%)",
        (
            f"Animal Resolution Accuracy: {animal_pass}/{len(animal_rows)} "
            f"({animal_pass / len(animal_rows) * 100:.1f}%)"
            if animal_rows
            else "Animal Resolution Accuracy: N/A"
        ),
        f"Context Accuracy: {context_pass}/{total} ({context_pass / total * 100:.1f}%)",
        (
            f"Implicit animal-context accuracy: {implicit_pass}/{len(implicit_rows)} "
            f"({implicit_pass / len(implicit_rows) * 100:.1f}%)"
            if implicit_rows
            else "Implicit animal-context accuracy: N/A"
        ),
        f"Animal Context Retention Depth (observed): {retention_depth(evaluated)} turni",
        "",
        "Collector",
        "-" * 30,
        f"Timeout: {timeout_count}/{total}",
        f"Risposte troncate: {truncated_count}/{total}",
    ]

    if latencies:
        lines.extend(
            [
                f"Latency min: {min(latencies):.0f} ms",
                f"Latency median: {statistics.median(latencies):.0f} ms",
                f"Latency mean: {statistics.mean(latencies):.0f} ms",
                f"Latency max: {max(latencies):.0f} ms",
            ]
        )

    lines.extend(["", "Flag / error counts", "-" * 30])

    if error_counts:
        for error, count in error_counts.most_common():
            lines.append(f"{error}: {count}")
    else:
        lines.append("Nessun errore/flag.")

    lines.extend(["", "Turni da revisionare", "-" * 30])

    for row in evaluated:
        if row["overall_status"] != "PASS":
            lines.append(
                f"{row['test_id']} | turn {row['turn']} | {row['overall_status']} | "
                f"{row['error_type'] or row['advice_flags'] or row['metric_flags']}"
            )

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Valutazione deterministica dei run conversazionali PECUS CHAIN."
    )
    parser.add_argument(
        "input",
        nargs="?",
        default="results/conversation_results.csv",
        help="CSV prodotto da run_conversation.py",
    )
    parser.add_argument(
        "--output",
        default="results/conversation_results_evaluated.csv",
        help="CSV valutato",
    )
    parser.add_argument(
        "--summary",
        default="results/qa_summary.txt",
        help="Riepilogo QA",
    )
    args = parser.parse_args()

    input_path = Path(args.input)
    output_path = Path(args.output)
    summary_path = Path(args.summary)

    with input_path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle, delimiter=";"))

    if not rows:
        raise SystemExit("Il CSV di input non contiene righe.")

    evaluated = evaluate_rows(rows)
    write_csv(output_path, evaluated)
    write_summary(summary_path, evaluated)

    print(f"Test valutati: {len(evaluated)}")
    print(f"CSV valutato: {output_path}")
    print(f"Summary: {summary_path}")

    counts = Counter(row["overall_status"] for row in evaluated)
    print(
        "Esito:",
        f"PASS={counts['PASS']}",
        f"REVIEW={counts['REVIEW']}",
        f"FAIL={counts['FAIL']}",
    )


if __name__ == "__main__":
    main()
