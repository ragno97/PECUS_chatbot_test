from pathlib import Path
import csv

OUTPUT = Path("tests/conversation_tests.csv")

OUTPUT.parent.mkdir(exist_ok=True)

tests = [
    {
        "test_id": "CONV_001",
        "turn": 1,
        "test_family": "animal_profile",
        "intent": "animal_profile",
        "question": "descrivi la 3118",
        "animal_explicit": True,
        "expected_animal": "3118",
        "expected_scope": "animal",
    },
    {
        "test_id": "CONV_002",
        "turn": 2,
        "test_family": "context_memory",
        "intent": "daily_milk_yield",
        "question": "quanto produce oggi?",
        "animal_explicit": False,
        "expected_animal": "3118",
        "expected_scope": "animal",
    },
    {
        "test_id": "CONV_003",
        "turn": 3,
        "test_family": "context_memory",
        "intent": "previous_milk_yield",
        "question": "e ieri?",
        "animal_explicit": False,
        "expected_animal": "3118",
        "expected_scope": "animal",
    },
    {
        "test_id": "CONV_004",
        "turn": 4,
        "test_family": "context_memory",
        "intent": "risk",
        "question": "ha qualche rischio?",
        "animal_explicit": False,
        "expected_animal": "3118",
        "expected_scope": "animal",
    },
    {
        "test_id": "CONV_005",
        "turn": 5,
        "test_family": "context_memory",
        "intent": "risk_reason",
        "question": "da cosa deriva?",
        "animal_explicit": False,
        "expected_animal": "3118",
        "expected_scope": "animal",
    },
    {
        "test_id": "CONV_006",
        "turn": 6,
        "test_family": "paraphrase",
        "intent": "daily_milk_yield",
        "question": "quanto latte ha fatto oggi la 3118?",
        "animal_explicit": True,
        "expected_animal": "3118",
        "expected_scope": "animal",
    },
    {
        "test_id": "CONV_007",
        "turn": 7,
        "test_family": "context_memory",
        "intent": "production_vs_expected",
        "question": "come sta andando rispetto al previsto?",
        "animal_explicit": False,
        "expected_animal": "3118",
        "expected_scope": "animal",
    },
    {
        "test_id": "CONV_008",
        "turn": 8,
        "test_family": "scope_switch",
        "intent": "herd_similar",
        "question": "ci sono altre bufale con lo stesso problema?",
        "animal_explicit": False,
        "expected_animal": "",
        "expected_scope": "herd",
    },
    {
        "test_id": "CONV_009",
        "turn": 9,
        "test_family": "scope_recovery",
        "intent": "daily_milk_yield",
        "question": "tornando alla 3118, qual è la sua produzione?",
        "animal_explicit": True,
        "expected_animal": "3118",
        "expected_scope": "animal",
    },
    {
        "test_id": "CONV_010",
        "turn": 10,
        "test_family": "context_memory",
        "intent": "daily_milk_yield",
        "question": "produzione oggi?",
        "animal_explicit": False,
        "expected_animal": "3118",
        "expected_scope": "animal",
    },
]

fieldnames = [
    "test_id",
    "turn",
    "test_family",
    "intent",
    "question",
    "animal_explicit",
    "expected_animal",
    "expected_scope",
]

with open(
    OUTPUT,
    "w",
    encoding="utf-8-sig",
    newline=""
) as f:

    writer = csv.DictWriter(
        f,
        fieldnames=fieldnames,
        delimiter=";"
    )

    writer.writeheader()
    writer.writerows(tests)

print("File creato correttamente:")
print(OUTPUT)

print()
print("Test scritti:", len(tests))