from __future__ import annotations

from playwright.sync_api import sync_playwright
from pathlib import Path
from datetime import datetime
import csv
import re
import time


BOT_NAME = "Marica Marches"
TEST_FILE = Path("tests/benchmark_v3.csv")
RESULTS_DIR = Path("results")
RESULTS_FILE = RESULTS_DIR / "benchmark_v3_results.csv"

TIMEOUT_SECONDS = 150
QUIET_SECONDS = 6
BETWEEN_QUESTIONS_SECONDS = 5
BETWEEN_SCENARIOS_SECONDS = 8

RESULTS_DIR.mkdir(parents=True, exist_ok=True)
RUN_ID = "V3_" + datetime.now().strftime("%Y%m%d_%H%M%S")


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def parse_whatsapp_datetime(metadata: str):
    if not metadata:
        return None
    m = re.search(r"\[(\d{1,2}):(\d{2}),\s*(\d{1,2})/(\d{1,2})/(\d{4})\]", metadata)
    if not m:
        return None
    hh, mm, dd, mon, yyyy = map(int, m.groups())
    return datetime(yyyy, mon, dd, hh, mm)


def message_key(message: dict) -> str:
    if message.get("message_id"):
        return "id:" + str(message["message_id"])
    return "fallback:" + str(message.get("metadata")) + "|" + normalize_text(
        message.get("text", "")
    )[:250]


def get_bot_messages(page):
    locator = page.locator(f'[data-pre-plain-text*="{BOT_NAME}:"]')
    messages = []

    for i in range(locator.count()):
        element = locator.nth(i)
        try:
            text = element.inner_text().strip()
            metadata = element.get_attribute("data-pre-plain-text")
            ancestor = element.locator("xpath=ancestor::*[@data-id][1]")
            message_id = None
            if ancestor.count() > 0:
                message_id = ancestor.get_attribute("data-id")
            if text:
                messages.append({
                    "message_id": message_id,
                    "metadata": metadata,
                    "message_dt": parse_whatsapp_datetime(metadata),
                    "text": text,
                    "dom_index": i,
                })
        except Exception:
            pass

    deduped = {}
    for m in messages:
        content_key = (m["metadata"], normalize_text(m["text"])[:220])
        if content_key not in deduped:
            deduped[content_key] = m
        else:
            e = deduped[content_key]
            if m["message_id"] and not e["message_id"]:
                e["message_id"] = m["message_id"]
            if len(m["text"]) > len(e["text"]):
                e["text"] = m["text"]

    return list(deduped.values())


def expand_message_by_id(page, message_id):
    if not message_id:
        return False
    try:
        node = page.locator(f'[data-id="{message_id}"]')
        if node.count() == 0:
            return False
        more = node.get_by_text("Leggi di più", exact=True)
        if more.count() > 0:
            more.last.click(timeout=3000)
            page.wait_for_timeout(800)
            return True
    except Exception:
        pass
    return False


def load_tests():
    with TEST_FILE.open("r", encoding="utf-8-sig", newline="") as f:
        return [
            {str(k).strip(): str(v).strip() if v is not None else "" for k, v in row.items()}
            for row in csv.DictReader(f, delimiter=";")
        ]


def save_result(test, result):
    exists = RESULTS_FILE.exists()
    with RESULTS_FILE.open("a", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f, delimiter=";")
        if not exists:
            writer.writerow([
                "run_id","test_id","scenario","scenario_turn","block",
                "test_family","probe_type","intent","question",
                "animal_explicit","expected_animal","expected_scope",
                "response","latency_ms","message_count","response_truncated",
                "message_ids","whatsapp_metadata","send_system_timestamp",
                "system_timestamp","collector_success","collector_note"
            ])
        writer.writerow([
            RUN_ID,test["test_id"],test["scenario"],test["scenario_turn"],test["block"],
            test["test_family"],test["probe_type"],test["intent"],test["question"],
            test["animal_explicit"],test["expected_animal"],test["expected_scope"],
            result["response"],
            result["latency_ms"] if result["latency_ms"] is not None else "",
            len(result["messages"]),result["truncated"],
            " | ".join(str(m.get("message_id")) for m in result["messages"]),
            " | ".join(str(m.get("metadata")) for m in result["messages"]),
            result["send_system_timestamp"],
            datetime.now().isoformat(timespec="seconds"),
            result["success"],result["note"],
        ])


def qualifying_new_messages(page, known_keys, send_minute):
    candidates = []
    for m in get_bot_messages(page):
        key = message_key(m)
        if key in known_keys:
            continue
        dt = m.get("message_dt")
        if dt is not None and dt < send_minute:
            continue
        candidates.append(m)

    candidates.sort(key=lambda m: (m.get("message_dt") or send_minute, m.get("dom_index", 0)))
    return candidates


def run_single_test(page, message_box, test, known_keys):
    print()
    print("=" * 78)
    print(f'{test["scenario"]} | {test["test_id"]} | turn {test["scenario_turn"]}')
    print("Block:", test["block"])
    print("Probe:", test["probe_type"])
    print("Domanda:", test["question"])
    print("=" * 78)

    for m in get_bot_messages(page):
        known_keys.add(message_key(m))

    send_dt = datetime.now()
    send_minute = send_dt.replace(second=0, microsecond=0)
    start = time.monotonic()

    message_box.click()
    message_box.fill(test["question"])
    message_box.press("Enter")

    print("Messaggio inviato. Attendo una nuova risposta...")

    deadline = time.monotonic() + TIMEOUT_SECONDS
    first_detection_time = None
    collected = {}

    while time.monotonic() < deadline:
        candidates = qualifying_new_messages(page, known_keys, send_minute)
        if candidates:
            first_detection_time = time.monotonic()
            for m in candidates:
                collected[message_key(m)] = m
            break
        page.wait_for_timeout(500)

    if not collected:
        return {
            "response":"","latency_ms":None,"messages":[],"truncated":False,
            "success":False,"note":"TIMEOUT_ABORT_RUN",
            "send_system_timestamp":send_dt.isoformat(timespec="seconds"),
        }

    latency_ms = int((first_detection_time - start) * 1000)
    print("Prima risposta rilevata dopo:", latency_ms, "ms")

    page.wait_for_timeout(1200)

    for m in qualifying_new_messages(page, known_keys, send_minute):
        collected[message_key(m)] = m

    for m in list(collected.values()):
        expand_message_by_id(page, m.get("message_id"))

    last_change = time.monotonic()
    last_keys = set(collected)

    while True:
        page.wait_for_timeout(500)
        current = {message_key(m): m for m in qualifying_new_messages(page, known_keys, send_minute)}
        current_keys = set(current)
        if current_keys != last_keys:
            last_keys = current_keys
            last_change = time.monotonic()
        collected.update(current)
        if time.monotonic() - last_change >= QUIET_SECONDS:
            break

    for m in qualifying_new_messages(page, known_keys, send_minute):
        collected[message_key(m)] = m

    logical = {}
    for m in collected.values():
        ck = (m["metadata"], normalize_text(m["text"])[:220])
        if ck not in logical:
            logical[ck] = m
        else:
            e = logical[ck]
            if m.get("message_id") and not e.get("message_id"):
                e["message_id"] = m["message_id"]
            if len(m["text"]) > len(e["text"]):
                e["text"] = m["text"]

    final_messages = sorted(
        logical.values(),
        key=lambda m: (m.get("message_dt") or send_minute, m.get("dom_index", 0))
    )

    response = "\n\n".join(m["text"].strip() for m in final_messages)
    truncated = "Leggi di più" in response

    for m in final_messages:
        known_keys.add(message_key(m))

    success = bool(final_messages and response.strip())
    note = "OK" if success else "EMPTY_FINAL_RESPONSE"

    print("--- RISPOSTA PECUS ---")
    print(response)
    print("-----------------------")
    print("Messaggi logici:", len(final_messages))
    print("Troncata:", truncated)

    return {
        "response":response,"latency_ms":latency_ms,"messages":final_messages,
        "truncated":truncated,"success":success,"note":note,
        "send_system_timestamp":send_dt.isoformat(timespec="seconds"),
    }


def main():
    tests = load_tests()
    print("PECUS Benchmark V3")
    print("Test caricati:", len(tests))
    print("Run ID:", RUN_ID)
    print("Output:", RESULTS_FILE)

    with sync_playwright() as p:
        context = p.chromium.launch_persistent_context(
            user_data_dir="./whatsapp_profile",
            headless=False,
        )

        page = context.pages[0]
        if not page.url.startswith("https://web.whatsapp.com"):
            page.goto("https://web.whatsapp.com")

        page.wait_for_timeout(5000)

        message_box = page.locator(
            '[contenteditable="true"][role="textbox"][data-tab="10"]'
        )
        message_box.wait_for(state="visible", timeout=30000)

        known_keys = {message_key(m) for m in get_bot_messages(page)}
        previous_scenario = None

        for index, test in enumerate(tests, 1):
            if previous_scenario and test["scenario"] != previous_scenario:
                print("\nNUOVO SCENARIO:", test["scenario"])
                page.wait_for_timeout(BETWEEN_SCENARIOS_SECONDS * 1000)

            result = run_single_test(page, message_box, test, known_keys)
            save_result(test, result)
            print(f"Salvato {index}/{len(tests)}")

            if not result["success"]:
                print()
                print("RUN INTERROTTO PER PROTEGGERE L'ALLINEAMENTO DOMANDA-RISPOSTA.")
                print("Ultimo test:", test["test_id"])
                print("Risultati parziali:", RESULTS_FILE)
                break

            previous_scenario = test["scenario"]

            if index < len(tests):
                page.wait_for_timeout(BETWEEN_QUESTIONS_SECONDS * 1000)

        print("\nRun terminato.")
        print("Risultati:", RESULTS_FILE)
        input("\nPremi INVIO per chiudere...")
        context.close()


if __name__ == "__main__":
    main()
