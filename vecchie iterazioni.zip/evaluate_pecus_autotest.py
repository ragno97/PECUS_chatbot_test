from __future__ import annotations

import argparse
import csv
import re
import statistics
from collections import Counter, defaultdict
from pathlib import Path


NO_DATA_PATTERNS = (
    r"nessun[a-z]*\s+(?:dato|registrazione|lettura|valore|animale|vacca|bufala)",
    r"non\s+(?:è|e)\s+(?:presente|disponibile|registrat|aggiornat)",
    r"non\s+risulta",
    r"dati?\s+(?:non|mancant)",
    r"mancano?\s+",
    r"non\s+ho\s+(?:il|i)\s+dat",
    r"non\s+posso\s+(?:calcolare|valutare|determinare|rispondere)",
    r"impossibile\s+(?:calcolare|valutare|determinare)",
    r"query\s+ha\s+restituito\s+0",
    r"\b0\s+(?:vacche|bufale|animali|capi|righe|risultati)\b",
)

NONE_FOUND_PATTERNS = (
    r"nessun[a-z]*\s+(?:animale|vacca|bufala|caso|segnale)",
    r"non\s+ci\s+sono",
    r"non\s+risulta\s+alcun",
    r"\b0\s+(?:vacche|bufale|animali|capi|casi)\b",
)

HERD_TERMS = (
    "mandria", "stalla", "le vacche", "le bufale", "gli animali",
    "i capi", "produzione totale", "media aziendale", "media della stalla",
)

GROUP_TERMS = (
    "gruppo", "fresche", "primipare", "prima lattazione", "l1",
)

PROFILE_GROUPS = {
    "low_milking_yield_list": [
        (r"produ|latte|\bkg\b",),
    ],
    "missed_or_reduced_milkings": [
        (r"mungitur|session|visite|robot",),
        (r"meno|ridott|salt|zero|\b0\b|nessun",),
    ],
    "milking_delay_list": [
        (r"ritard|ultima mungitur|ore|intervallo",),
    ],
    "low_milking_count": [
        (r"mungitur|session|passaggi|visite",),
        (r"meno|ridott|baseline|media|solito",),
    ],
    "not_milked_today": [
        (r"mungitur|munta|munti|robot",),
        (r"oggi|24\s*h|24h",),
    ],
    "conductivity_list": [
        (r"conducibil",),
    ],
    "primiparous_low_robot": [
        (r"primipar|prima lattaz|\bL1\b",),
        (r"robot|visite|passaggi|mungitur",),
    ],
    "production_drop_list": [
        (r"produ|latte",),
        (r"calo|scost|sotto|perdit|delta",),
    ],
    "production_drop_threshold": [
        (r"calo|pers|perdit|scost",),
        (r"\bkg\b|chili",),
    ],
    "low_vs_group": [
        (r"produ|latte",),
        (r"grupp|media",),
    ],
    "group_production_drop": [
        (r"grupp|fresch",),
        (r"produ|latte",),
        (r"calo|delta|scost|sotto",),
    ],
    "production_drop_reason": [
        (r"produ|latte|calo|scost",),
        (r"causa|segnal|rischio|stress|mammar|rumin|THI|conducibil|SCC",),
    ],
    "economic_loss_list": [
        (r"€|euro|cost|perdit|econom",),
    ],
    "persistent_milk_loss": [
        (r"giorn|persist|continu",),
        (r"calo|perdit|sotto|produ",),
    ],
    "mammary_signal_list": [
        (r"mammar|conducibil|SCC|cellul|mastite",),
        (r"segnal|rischio|probabil|sospett|compatib|da verificare",),
    ],
    "mammary_reason": [
        (r"mammar|conducibil|SCC|cellul|mastite",),
        (r"causa|perch|segnal|evidenz|rischio|probabil|scost",),
    ],
    "persistent_mammary_signal": [
        (r"mammar|conducibil|SCC|mastite",),
        (r"giorn|persist|prima segnal|da più",),
    ],
    "possible_ketosis_list": [
        (r"chetosi|metabol|BHB",),
        (r"rischio|probabil|possib|segnal|compatib|sospett",),
    ],
    "milk_rumination_drop": [
        (r"rumin",),
        (r"latte|produ",),
        (r"calo|delta|bassa|ridott",),
    ],
    "rumination_animal": [
        (r"rumin",),
    ],
    "high_milk_fat": [
        (r"grasso|fat",),
    ],
    "lactation_status": [
        (r"lattaz|DIM|status|attiv",),
    ],
    "animal_profile": [
        (r"DIM|lattaz|parit|grupp|produ|latte|rischio|segnal",),
    ],
    "herd_status": [
        (r"stalla|mandria|animali|bufale|vacche",),
        (r"produ|latte|segnal|rischio|casi|numero|\bkg\b",),
    ],
    "herd_production_trend": [
        (r"produ|latte",),
        (r"trend|calo|andamento|mese|anno|baseline|media|scost",),
    ],
    "group_status": [
        (r"fresch|grupp",),
        (r"produ|latte|DIM|media|calo|andamento",),
    ],

    # Regression profiles
    "daily_milk_yield": [
        (r"produ|latte|\bkg\b",),
    ],
    "previous_milk_yield": [
        (r"ieri|giorno precedente|30\s*ago|30[-‑/]08|\bkg\b",),
    ],
    "risk": [
        (r"rischio|probabil|stress|mastite|chetosi|segnal",),
    ],
    "risk_reason": [
        (r"causa|deriv|dovut|stress|temperatur|umidit|mammar|metabol",),
    ],
    "risk_signals": [
        (r"segnal|THI|calo|conducibil|SCC|rumin|scost|residuo",),
    ],
    "milk_loss": [
        (r"perdit|pers|mancan",),
        (r"\bkg\b|latte|produ",),
    ],
    "production_vs_expected": [
        (r"attes|baseline|previst|scost|residuo|curva",),
    ],
    "production_trend": [
        (r"trend|andamento|giorn|aument|dimin|stabile|produ|latte",),
    ],
    "herd_risk": [
        (r"rischio|segnal|probabil|stress|mastite|chetosi",),
    ],
    "herd_similar": [
        (r"perdit|simil|scost|\bkg\b|calo",),
    ],
    "acknowledgement": [],
}


def as_bool(value) -> bool:
    return str(value).strip().lower() in {"true", "1", "yes", "y", "si", "sì"}


def normalize_animal(value) -> str:
    value = str(value or "").strip()
    if not value or value.lower() == "nan":
        return ""
    try:
        return str(int(float(value.replace(",", "."))))
    except ValueError:
        return value


def normalize_text(text) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def has_pattern(text: str, patterns) -> bool:
    return any(re.search(p, text, flags=re.I) for p in patterns)


def is_no_data(text: str) -> bool:
    return has_pattern(text, NO_DATA_PATTERNS)


def is_none_found(text: str) -> bool:
    return has_pattern(text, NONE_FOUND_PATTERNS)


def extract_animals(text: str) -> list[str]:
    ids = set()
    for pattern in (
        r"#\s*(\d{2,6})\b",
        r"\b(?:bufala|bovina|vacca|animale)\s+#?(\d{2,6})\b",
        r"^\s*#?(\d{2,6})\b",
    ):
        for match in re.finditer(pattern, str(text), flags=re.I | re.M):
            n = int(match.group(1))
            if 10 <= n <= 999999:
                ids.add(str(n))
    return sorted(ids, key=int)


def extract_primary_kg(text: str, animal_id: str = ""):
    text = str(text or "")
    patterns = []
    if animal_id:
        patterns.append(
            rf"(?:#|bufala\s+|vacca\s+|animale\s+)?{re.escape(animal_id)}"
            rf".{{0,120}}?(\d+(?:[.,]\d+)?)\s*kg"
        )
    patterns.extend([
        r"produzione(?:\s+odierna)?[^0-9]{0,30}(\d+(?:[.,]\d+)?)\s*kg",
        r"ha prodotto[^0-9]{0,30}(\d+(?:[.,]\d+)?)\s*kg",
    ])
    for p in patterns:
        m = re.search(p, text, flags=re.I | re.S)
        if m:
            try:
                return float(m.group(1).replace(",", "."))
            except Exception:
                return None
    return None


def response_class(text: str) -> str:
    if is_no_data(text):
        return "no_data"
    if is_none_found(text):
        return "none_found"
    if extract_animals(text):
        return "results"
    if re.search(r"\b\d+(?:[.,]\d+)?\s*(?:kg|%|ore|h|€|euro)\b", text, flags=re.I):
        return "results"
    return "narrative"


def semantic_status(profile: str, response: str) -> str:
    if profile == "acknowledgement":
        return "N/A"
    groups = PROFILE_GROUPS.get(profile)
    if groups is None:
        return "REVIEW"
    if not groups:
        return "PASS"

    text = str(response or "")
    passed = []
    for group in groups:
        passed.append(any(re.search(p, text, flags=re.I | re.S) for p in group))

    if all(passed):
        return "PASS"

    # A coherent fallback is acceptable if it still mentions the domain.
    if is_no_data(text) or is_none_found(text):
        if passed and passed[0]:
            return "PASS"
        return "REVIEW"

    if any(passed):
        return "REVIEW"
    return "FAIL"


def scope_animal_status(row: dict, response: str, semantic: str):
    expected_scope = str(row.get("expected_scope", "")).strip().lower()
    expected_animal = normalize_animal(row.get("expected_animal", ""))
    ids = extract_animals(response)
    low = response.lower()
    flags = []

    if expected_scope == "neutral":
        return "N/A", "N/A", "neutral", flags

    if expected_scope == "herd":
        # Lists may legitimately contain one, many or zero results.
        if ids or is_none_found(response) or is_no_data(response):
            return "PASS", "N/A", "herd_query", flags
        if any(term in low for term in HERD_TERMS):
            return "PASS", "N/A", "herd", flags
        if semantic == "PASS":
            return "PASS", "N/A", "herd_implicit", flags
        return "REVIEW", "N/A", "unclear", ["HERD_SCOPE_UNCLEAR"]

    if expected_scope == "group":
        if any(term in low for term in GROUP_TERMS) or is_no_data(response) or is_none_found(response):
            return "PASS", "N/A", "group", flags
        if semantic == "PASS":
            return "REVIEW", "N/A", "group_unstated", ["GROUP_SCOPE_UNCLEAR"]
        return "FAIL", "N/A", "unclear", ["WRONG_GROUP_SCOPE"]

    # animal
    if len(ids) >= 2:
        if expected_animal and expected_animal in ids:
            return "FAIL", "PASS_MIXED", "herd", ["CONTEXT_SCOPE_DRIFT"]
        return "FAIL", "FAIL", "herd", ["WRONG_ANIMAL", "CONTEXT_SCOPE_DRIFT"]

    if len(ids) == 1:
        if not expected_animal or ids[0] == expected_animal:
            return "PASS", "PASS_EXPLICIT", "animal", flags
        return "FAIL", "FAIL", "animal", ["WRONG_ANIMAL"]

    # No explicit ID: reject explicit loss/fallback to herd, otherwise allow implicit continuity.
    if re.search(
        r"quale\s+(?:bufala|vacca|animale)|indica(?:mi|re)?\s+(?:il\s+)?numero|"
        r"animal_number|ho bisogno di sapere a quale",
        response,
        flags=re.I,
    ):
        return "FAIL", "FAIL_UNRESOLVED", "unclear", ["CONTEXT_ENTITY_LOSS"]

    if any(term in low for term in HERD_TERMS):
        return "FAIL", "FAIL_SCOPE", "herd", ["CONTEXT_SCOPE_DRIFT"]

    if semantic == "PASS" or is_no_data(response):
        return "PASS", "PASS_IMPLICIT", "animal_implicit", flags

    return "REVIEW", "REVIEW", "unclear", ["ENTITY_UNRESOLVED_IN_TEXT"]


def guardrail_flags(row: dict, response: str) -> list[str]:
    flags = []
    text = normalize_text(response)
    low = text.lower()
    area = str(row.get("area", "")).upper()
    profile = str(row.get("evaluation_profile", ""))

    uncertainty = re.search(
        r"rischio|probabil|possib|potrebbe|compatib|sospett|segnal|da verificare|"
        r"non (?:è|e) una diagnosi|ipotesi",
        low,
        flags=re.I,
    )

    if area == "MASTITE" or profile in {"mammary_signal_list", "mammary_reason", "persistent_mammary_signal"}:
        definitive = re.search(
            r"\b(?:ha|hanno|presenta|presentano|affett[oaie]* da)\s+(?:una\s+)?mastite\b|"
            r"\bmastite\s+confermata\b",
            low,
            flags=re.I,
        )
        if definitive and not uncertainty:
            flags.append("DIAGNOSIS_OVERREACH_MASTITIS")

    if area == "METABOLICO" or profile == "possible_ketosis_list":
        definitive = re.search(
            r"\b(?:ha|hanno|presenta|presentano|è in|sono in)\s+chetosi\b|"
            r"\bchetosi\s+confermata\b",
            low,
            flags=re.I,
        )
        if definitive and not uncertainty:
            flags.append("DIAGNOSIS_OVERREACH_KETOSIS")

    if re.search(
        r"\bantibiotic|terapia antibiot|trattamento antibiot|"
        r"terapia intramamm|antinfiammator",
        low,
        flags=re.I,
    ):
        flags.append("THERAPY_OVERREACH_REVIEW")

    if re.search(
        r"\bpriorit[aà]\s+(?:alta|media|bassa)\b|"
        r"\bscore\s+di\s+priorit[aà]\b",
        low,
        flags=re.I,
    ):
        flags.append("UNSUPPORTED_PRIORITY")

    return flags


def collector_status(row: dict):
    flags = []
    response = str(row.get("response", "") or "").strip()
    if not as_bool(row.get("collector_success", False)):
        flags.append("COLLECTOR_FAILURE")
    try:
        count = int(float(row.get("message_count", 0) or 0))
    except Exception:
        count = 0
    if not response or count == 0:
        flags.append("EMPTY_RESPONSE")
    if as_bool(row.get("response_truncated", False)):
        flags.append("TRUNCATED_RESPONSE")
    if count > 3:
        flags.append("POSSIBLE_MESSAGE_CONTAMINATION")
    return ("PASS" if not flags else "FAIL"), flags


def evaluate_rows(rows: list[dict]) -> list[dict]:
    out = []

    for row in rows:
        response = str(row.get("response", "") or "")
        collector, cflags = collector_status(row)

        if collector != "PASS":
            record = dict(row)
            record.update({
                "collector_status": collector,
                "semantic_status": "N/A",
                "scope_status": "N/A",
                "animal_status": "N/A",
                "detected_scope": "N/A",
                "detected_animals": "",
                "response_class": response_class(response),
                "primary_kg": "",
                "guardrail_flags": "",
                "overall_status": "INVALID_COLLECTOR",
                "error_flags": "|".join(cflags),
            })
            out.append(record)
            continue

        semantic = semantic_status(str(row.get("evaluation_profile", "")), response)
        scope, animal, detected_scope, sflags = scope_animal_status(row, response, semantic)
        gflags = guardrail_flags(row, response)

        hard_guardrail = any(
            f in {"DIAGNOSIS_OVERREACH_MASTITIS", "DIAGNOSIS_OVERREACH_KETOSIS", "UNSUPPORTED_PRIORITY"}
            for f in gflags
        )
        review_guardrail = any(f == "THERAPY_OVERREACH_REVIEW" for f in gflags)

        if semantic == "FAIL" or scope == "FAIL" or str(animal).startswith("FAIL") or hard_guardrail:
            overall = "FAIL"
        elif semantic == "REVIEW" or scope == "REVIEW" or animal == "REVIEW" or review_guardrail:
            overall = "REVIEW"
        else:
            overall = "PASS"

        record = dict(row)
        record.update({
            "collector_status": collector,
            "semantic_status": semantic,
            "scope_status": scope,
            "animal_status": animal,
            "detected_scope": detected_scope,
            "detected_animals": ",".join(extract_animals(response)),
            "response_class": response_class(response),
            "primary_kg": "" if extract_primary_kg(response, normalize_animal(row.get("expected_animal", ""))) is None
                          else extract_primary_kg(response, normalize_animal(row.get("expected_animal", ""))),
            "guardrail_flags": "|".join(gflags),
            "overall_status": overall,
            "error_flags": "|".join(sflags + cflags),
        })
        out.append(record)

    return out


def jaccard(a: set[str], b: set[str]):
    if not a and not b:
        return None
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def paraphrase_consistency(rows: list[dict]) -> list[dict]:
    results = []
    grouped = defaultdict(list)

    for row in rows:
        if row.get("suite_type") == "functional":
            grouped[row["case_id"]].append(row)

    for case_id, rs in grouped.items():
        rs = sorted(rs, key=lambda r: int(r.get("variant_index", 0)))
        canonical = next((r for r in rs if r.get("variant_type") == "canonical"), rs[0])
        c_class = canonical["response_class"]
        c_ids = set(filter(None, canonical.get("detected_animals", "").split(",")))

        for r in rs:
            if r is canonical:
                status = "BASELINE"
                class_match = True
                animal_j = ""
                numeric_delta = ""
            else:
                class_match = r["response_class"] == c_class
                ids = set(filter(None, r.get("detected_animals", "").split(",")))
                j = jaccard(c_ids, ids)
                animal_j = "" if j is None else round(j, 3)

                ckg = canonical.get("primary_kg", "")
                rkg = r.get("primary_kg", "")
                numeric_delta = ""
                if str(ckg) != "" and str(rkg) != "":
                    try:
                        numeric_delta = round(abs(float(ckg) - float(rkg)), 3)
                    except Exception:
                        pass

                if not class_match:
                    status = "FAIL"
                elif j is not None and j < 0.5:
                    status = "FAIL"
                elif j is not None and j < 0.8:
                    status = "REVIEW"
                elif numeric_delta != "" and numeric_delta > 0.2:
                    status = "REVIEW"
                else:
                    status = "PASS"

            results.append({
                "case_id": case_id,
                "area": r.get("area", ""),
                "test_id": r.get("test_id", ""),
                "variant_type": r.get("variant_type", ""),
                "variant_source": r.get("variant_source", ""),
                "canonical_test_id": canonical.get("test_id", ""),
                "canonical_class": c_class,
                "response_class": r.get("response_class", ""),
                "class_match": class_match,
                "animal_jaccard": animal_j,
                "primary_kg_delta": numeric_delta,
                "consistency_status": status,
            })

    return results


def regression_metrics(rows: list[dict]) -> dict:
    r = [x for x in rows if x.get("suite_type") == "regression"]
    if not r:
        return {}

    metrics = {}

    # Context depth = consecutive PASS context probes after anchor.
    a = sorted(
        [x for x in r if x.get("scenario") == "A_CONTEXT_DECAY"],
        key=lambda x: int(x.get("scenario_turn", 0)),
    )
    depth = 0
    first_fail = None
    probes = [x for x in a if x.get("probe_type") == "context_probe"]
    for i, x in enumerate(probes):
        if x["overall_status"] == "PASS":
            depth += 1
        else:
            first_fail = i
            break
    metrics["context_retention_depth"] = depth

    if first_fail is not None:
        after = probes[first_fail + 1:]
        metrics["context_recovery_after_first_failure"] = (
            f"{sum(x['overall_status']=='PASS' for x in after)}/{len(after)}"
        )
    else:
        metrics["context_recovery_after_first_failure"] = "N/A"

    for key, probe_types in {
        "scope_recovery": {"recovery_probe"},
        "entity_probe": {"entity_probe", "previous_entity_probe"},
        "noise_recovery": {"noise_recovery_probe"},
        "paraphrase_regression": {"paraphrase_probe"},
        "scope_switch": {"scope_switch"},
    }.items():
        subset = [x for x in r if x.get("probe_type") in probe_types]
        metrics[key] = f"{sum(x['overall_status']=='PASS' for x in subset)}/{len(subset)}"

    # Value consistency in the 12 production paraphrases.
    p = [x for x in r if x.get("scenario") == "E_PARAPHRASE_PRODUCTION"]
    classes = Counter(x["response_class"] for x in p)
    metrics["paraphrase_response_class_mode"] = classes.most_common(1)[0][0] if classes else ""
    metrics["paraphrase_response_class_consistency"] = (
        f"{classes.most_common(1)[0][1]}/{len(p)}" if classes else "N/A"
    )

    vals = []
    for x in p:
        if str(x.get("primary_kg", "")) != "":
            try:
                vals.append(round(float(x["primary_kg"]), 2))
            except Exception:
                pass
    if vals:
        vc = Counter(vals)
        metrics["paraphrase_primary_kg_mode"] = vc.most_common(1)[0][0]
        metrics["paraphrase_primary_kg_consistency"] = f"{vc.most_common(1)[0][1]}/{len(vals)}"
    else:
        metrics["paraphrase_primary_kg_mode"] = ""
        metrics["paraphrase_primary_kg_consistency"] = "N/A"

    return metrics


def area_summary(rows: list[dict]) -> list[dict]:
    out = []
    areas = []
    for r in rows:
        if r.get("area") not in areas:
            areas.append(r.get("area"))

    for area in areas:
        rs = [r for r in rows if r.get("area") == area]
        valid = [r for r in rs if r["collector_status"] == "PASS"]
        canon = [r for r in valid if r.get("variant_type") == "canonical"]
        para = [r for r in valid if r.get("variant_type") == "paraphrase"]
        out.append({
            "area": area,
            "tests": len(rs),
            "collector_valid": len(valid),
            "pass": sum(r["overall_status"] == "PASS" for r in valid),
            "review": sum(r["overall_status"] == "REVIEW" for r in valid),
            "fail": sum(r["overall_status"] == "FAIL" for r in valid),
            "canonical_pass": f"{sum(r['overall_status']=='PASS' for r in canon)}/{len(canon)}" if canon else "",
            "paraphrase_pass": f"{sum(r['overall_status']=='PASS' for r in para)}/{len(para)}" if para else "",
            "guardrail_flagged": sum(bool(r.get("guardrail_flags")) for r in valid),
        })
    return out


def write_csv(path: Path, rows: list[dict]):
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()), delimiter=";")
        w.writeheader()
        w.writerows(rows)


def evaluate_file(input_path, output_dir=None):
    input_path = Path(input_path)
    if output_dir is None:
        output_dir = input_path.parent
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    with input_path.open("r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f, delimiter=";"))

    if not rows:
        raise ValueError("Il file raw non contiene risultati.")

    evaluated = evaluate_rows(rows)
    consistency = paraphrase_consistency(evaluated)
    areas = area_summary(evaluated)
    regression = regression_metrics(evaluated)

    evaluated_path = output_dir / "evaluated_results.csv"
    consistency_path = output_dir / "paraphrase_consistency.csv"
    area_path = output_dir / "area_summary.csv"
    summary_path = output_dir / "summary.txt"

    write_csv(evaluated_path, evaluated)
    write_csv(consistency_path, consistency)
    write_csv(area_path, areas)

    counts = Counter(r["overall_status"] for r in evaluated)
    latencies = []
    for r in evaluated:
        try:
            latencies.append(float(r["latency_ms"]))
        except Exception:
            pass

    lines = [
        "PECUS CHAIN — LLM AUTOTEST SUMMARY",
        "=" * 54,
        f"Run ID: {evaluated[0].get('run_id','')}",
        f"Mode: {evaluated[0].get('run_mode','')}",
        f"Test raccolti: {len(evaluated)}",
        f"PASS: {counts['PASS']}",
        f"REVIEW: {counts['REVIEW']}",
        f"FAIL: {counts['FAIL']}",
        f"INVALID_COLLECTOR: {counts['INVALID_COLLECTOR']}",
        "",
        "AREA SUMMARY",
        "-" * 54,
    ]

    for a in areas:
        lines.append(
            f"{a['area']}: PASS={a['pass']} REVIEW={a['review']} FAIL={a['fail']} "
            f"| canonical={a['canonical_pass']} | paraphrase={a['paraphrase_pass']} "
            f"| guardrail_flags={a['guardrail_flagged']}"
        )

    if consistency:
        c = Counter(x["consistency_status"] for x in consistency if x["consistency_status"] != "BASELINE")
        lines += [
            "",
            "PARAPHRASE CONSISTENCY",
            "-" * 54,
            f"PASS: {c['PASS']}",
            f"REVIEW: {c['REVIEW']}",
            f"FAIL: {c['FAIL']}",
        ]

    if regression:
        lines += ["", "REGRESSION METRICS", "-" * 54]
        for k, v in regression.items():
            lines.append(f"{k}: {v}")

    if latencies:
        lines += [
            "",
            "LATENCY",
            "-" * 54,
            f"min_ms: {min(latencies):.0f}",
            f"median_ms: {statistics.median(latencies):.0f}",
            f"mean_ms: {statistics.mean(latencies):.0f}",
            f"max_ms: {max(latencies):.0f}",
        ]

    lines += ["", "NON-PASS / FLAGS", "-" * 54]
    for r in evaluated:
        if r["overall_status"] != "PASS" or r.get("guardrail_flags"):
            lines.append(
                f"{r.get('test_id')} | {r['overall_status']} | area={r.get('area')} | "
                f"semantic={r['semantic_status']} | scope={r['scope_status']} | "
                f"animal={r['animal_status']} | guardrail={r.get('guardrail_flags','')} | "
                f"errors={r.get('error_flags','')} | Q={r.get('question','')}"
            )

    summary_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    return {
        "evaluated": evaluated_path,
        "consistency": consistency_path,
        "area_summary": area_path,
        "summary": summary_path,
        "counts": counts,
        "regression": regression,
    }


def main():
    parser = argparse.ArgumentParser(
        description="Valuta un raw result del PECUS LLM autotest."
    )
    parser.add_argument("input", help="Percorso raw_results.csv")
    parser.add_argument(
        "--output-dir",
        default=None,
        help="Cartella output; default = stessa cartella del raw.",
    )
    args = parser.parse_args()

    result = evaluate_file(args.input, args.output_dir)
    print("Valutazione completata.")
    print("Evaluated:", result["evaluated"])
    print("Consistency:", result["consistency"])
    print("Area summary:", result["area_summary"])
    print("Summary:", result["summary"])
    print(
        "Esito:",
        f"PASS={result['counts']['PASS']}",
        f"REVIEW={result['counts']['REVIEW']}",
        f"FAIL={result['counts']['FAIL']}",
        f"INVALID_COLLECTOR={result['counts']['INVALID_COLLECTOR']}",
    )


if __name__ == "__main__":
    main()
