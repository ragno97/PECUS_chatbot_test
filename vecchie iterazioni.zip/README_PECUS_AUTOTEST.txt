PECUS CHAIN — CURRENT LLM AUTOTEST

FILES
-----
run_pecus_autotest.py
    Runner Playwright + collector WhatsApp + valutazione automatica.

evaluate_pecus_autotest.py
    Rivaluta un raw_results.csv senza inviare nuovi messaggi.

tests/pecus_llm_current_suite.csv
    Catalogo corrente:
    - 27 domande canoniche selezionate manualmente
    - 52 parafrasi funzionali
    - 53 regression test V3
    Totale: 132 test

PECUS_LLM_Autotest_Current.xlsx
    Catalogo leggibile con mapping alla matrice PECUS originale e riepilogo per area.

MODALITA'
---------
smoke
    Solo le 27 domande canoniche selezionate.

functional
    27 canoniche + 52 parafrasi funzionali = 79 test.

regression
    53 test tecnici V3: context decay, scope recovery, entity switching,
    conversational noise, paraphrase production.

all
    79 functional + 53 regression = 132 test.

PRIMO AVVIO CONSIGLIATO
------------------------
py run_pecus_autotest.py --mode smoke

Poi:
py run_pecus_autotest.py --mode functional

Per la regressione tecnica:
py run_pecus_autotest.py --mode regression

Per tutto:
py run_pecus_autotest.py --mode all

OUTPUT
------
Ogni run crea una cartella autonoma:
results/AUTO_YYYYMMDD_HHMMSS/

contenente:
- suite_snapshot.csv
- raw_results.csv
- evaluated_results.csv
- paraphrase_consistency.csv
- area_summary.csv
- summary.txt

NOTE METODOLOGICHE
------------------
1. La stessa chat WhatsApp viene mantenuta: non viene eseguito reset del contesto.
2. In caso di timeout il run si interrompe per evitare lo sfasamento domanda-risposta.
3. Le parafrasi funzionali provenienti dal package originale NON sono marcate come
   gia' validate: vengono testate ora.
4. Le 12 parafrasi di produzione V3 sono conservate nella regressione e marcate
   come precedentemente validate dal V3.1.
5. V3.1 non era un nuovo runner: era una revisione dell'evaluator applicata allo
   stesso raw V3.
6. Domande colloquiali come "chi ha la mastite?" e "chi ha chetosi?" devono essere
   valutate come richieste di rischio/segnale: PECUS non deve trasformarle in
   diagnosi cliniche certe.
7. La priorita' non e' inclusa nei criteri: non e' una funzionalita' implementata.
