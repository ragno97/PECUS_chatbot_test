from pathlib import Path
import csv

OUTPUT = Path("tests/benchmark_v3.csv")
OUTPUT.parent.mkdir(parents=True, exist_ok=True)

rows = []

def add(test_id, scenario, turn, family, intent, question,
        animal_explicit, expected_animal, expected_scope, probe_type,
        block=""):
    rows.append([
        test_id, scenario, turn, family, intent, question,
        animal_explicit, expected_animal, expected_scope, probe_type, block
    ])

a_questions = [
    ("animal_profile", "descrivi la 3118", True, "anchor"),
    ("daily_milk_yield", "quanto produce oggi?", False, "context_probe"),
    ("previous_milk_yield", "e ieri?", False, "context_probe"),
    ("risk", "che rischio ha?", False, "context_probe"),
    ("risk_reason", "qual è la causa principale?", False, "context_probe"),
    ("risk_signals", "quali segnali lo supportano?", False, "context_probe"),
    ("milk_loss", "quanto latte sta perdendo?", False, "context_probe"),
    ("production_vs_expected", "rispetto all'atteso quanto è sotto?", False, "context_probe"),
    ("production_trend", "come è cambiata negli ultimi giorni?", False, "context_probe"),
    ("risk", "quindi qual è la situazione principale adesso?", False, "context_probe"),
]
for i, (intent, q, explicit, probe) in enumerate(a_questions, 1):
    add(f"A_DECAY_{i:03d}", "A_CONTEXT_DECAY", i,
        "context_memory" if i > 1 else "anchor",
        intent, q, explicit, "3118", "animal", probe, "A")

b = [
    ("animal_profile", "descrivi la 3118", True, "3118", "animal", "anchor", "B1"),
    ("daily_milk_yield", "quanto produce oggi?", False, "3118", "animal", "animal_probe", "B1"),
    ("herd_risk", "quali bufale sono a rischio oggi?", False, "", "herd", "scope_switch", "B1"),
    ("daily_milk_yield", "tornando alla bufala di cui parlavamo prima, quanto produce oggi?", False, "3118", "animal", "recovery_probe", "B1"),
    ("animal_profile", "parliamo di nuovo della 3118", True, "3118", "animal", "anchor", "B2"),
    ("herd_similar", "quali altre bufale hanno una perdita di latte simile?", False, "", "herd", "scope_switch", "B2"),
    ("risk", "e quella di prima che rischio ha?", False, "3118", "animal", "recovery_probe", "B2"),
]
for i, (intent, q, explicit, animal, scope, probe, block) in enumerate(b, 1):
    add(f"B_SCOPE_{i:03d}", "B_SCOPE_RECOVERY", i, "scope_recovery",
        intent, q, explicit, animal, scope, probe, block)

c = [
    ("animal_profile", "descrivi la 3118", True, "3118", "anchor"),
    ("daily_milk_yield", "quanto produce oggi?", False, "3118", "entity_probe"),
    ("animal_profile", "ora passa alla 2516", True, "2516", "entity_switch"),
    ("daily_milk_yield", "quanto produce oggi?", False, "2516", "entity_probe"),
    ("risk", "che rischio ha?", False, "2516", "entity_probe"),
    ("animal_profile", "torna alla 3118", True, "3118", "entity_switch"),
    ("daily_milk_yield", "quanto produce oggi?", False, "3118", "entity_probe"),
    ("animal_profile", "ora passa di nuovo alla 2516", True, "2516", "entity_switch"),
    ("daily_milk_yield", "e l'altra invece, quanto produce oggi?", False, "3118", "previous_entity_probe"),
]
for i, (intent, q, explicit, animal, probe) in enumerate(c, 1):
    add(f"C_ENTITY_{i:03d}", "C_ENTITY_SWITCH", i, "entity_switch",
        intent, q, explicit, animal, "animal", probe, "C")

noise_blocks = [
    ("D1", ["ok"], "daily_milk_yield", "quanto produce oggi?"),
    ("D3", ["ok", "capito", "grazie"], "risk", "che rischio ha?"),
    ("D5", ["ok", "capito", "grazie", "bene", "perfetto"], "daily_milk_yield", "quanto produce oggi?"),
]

turn = 0
counter = 0
for block, noises, final_intent, final_question in noise_blocks:
    turn += 1; counter += 1
    add(f"D_NOISE_{counter:03d}", "D_NOISE_RETENTION", turn, "noise_retention",
        "animal_profile", "descrivi la 3118", True, "3118", "animal", "anchor", block)
    for noise in noises:
        turn += 1; counter += 1
        add(f"D_NOISE_{counter:03d}", "D_NOISE_RETENTION", turn, "noise_retention",
            "acknowledgement", noise, False, "", "neutral", "noise", block)
    turn += 1; counter += 1
    add(f"D_NOISE_{counter:03d}", "D_NOISE_RETENTION", turn, "noise_retention",
        final_intent, final_question, False, "3118", "animal", "noise_recovery_probe", block)

paraphrases = [
    "Quanto produce oggi la 3118?",
    "Quanti kg di latte ha fatto oggi la 3118?",
    "3118 produzione oggi?",
    "La 3118 oggi quanto mi ha fatto?",
    "Oggi la 3118 quanto ha prodotto?",
    "Qual è la produzione giornaliera della 3118?",
    "Mi dai la produzione odierna della 3118?",
    "3118 quanti kg oggi?",
    "Quanto latte ha prodotto oggi la 3118?",
    "quanto ha prodoto oggi la 3118?",
    "Produzione della 3118 nelle ultime 24 ore?",
    "La 3118, oggi, a quanti kg è arrivata?",
]
for i, q in enumerate(paraphrases, 1):
    add(f"E_PARA_{i:03d}", "E_PARAPHRASE_PRODUCTION", i, "paraphrase",
        "daily_milk_yield", q, True, "3118", "animal", "paraphrase_probe", "E")

headers = [
    "test_id", "scenario", "scenario_turn", "test_family", "intent",
    "question", "animal_explicit", "expected_animal", "expected_scope",
    "probe_type", "block"
]

with OUTPUT.open("w", encoding="utf-8-sig", newline="") as f:
    writer = csv.writer(f, delimiter=";")
    writer.writerow(headers)
    writer.writerows(rows)

print("Benchmark V3 creato:", OUTPUT)
print("Test totali:", len(rows))
for scenario in sorted({r[1] for r in rows}):
    print(scenario, sum(r[1] == scenario for r in rows))
