from __future__ import annotations
import argparse, csv, re, statistics
from collections import Counter, defaultdict
from pathlib import Path

NO_DATA = (
    r"nessun[a-z]*\s+(?:dato|registrazione|lettura|valore|animale|vacca|bufala)",
    r"non\s+(?:è|e)\s+(?:presente|disponibile|registrat|aggiornat)",
    r"non\s+risulta", r"dati?\s+(?:non|mancant)", r"mancano?\s+",
    r"non\s+ho\s+(?:il|i)\s+dat", r"non\s+posso\s+(?:calcolare|valutare|determinare|rispondere)",
    r"impossibile\s+(?:calcolare|valutare|determinare)", r"query\s+ha\s+restituito\s+0",
    r"\b0\s+(?:vacche|bufale|animali|capi|righe|risultati)\b",
)
NONE_FOUND = (
    r"nessun[a-z]*\s+(?:animale|vacca|bufala|caso|segnale)",
    r"non\s+ci\s+sono", r"non\s+risulta\s+alcun",
    r"\b0\s+(?:vacche|bufale|animali|capi|casi)\b",
)
HERD_TERMS = ("mandria","stalla","le vacche","le bufale","gli animali","i capi","produzione totale","media aziendale","media della stalla")
GROUP_TERMS = ("gruppo","fresche","primipare","prima lattazione","l1")

def b(v): return str(v).strip().lower() in {"true","1","yes","y","si","sì"}
def norm(v): return re.sub(r"\s+"," ",str(v or "")).strip()
def no_data(t): return any(re.search(p,t,re.I) for p in NO_DATA)
def none_found(t): return any(re.search(p,t,re.I) for p in NONE_FOUND)

def animal(v):
    v=str(v or "").strip()
    if not v: return ""
    try: return str(int(float(v.replace(",","."))))
    except: return v

def ids(text):
    out=set()
    for p in (r"#\s*(\d{2,6})\b",r"\b(?:bufala|bovina|vacca|animale)\s+#?(\d{2,6})\b",r"^\s*#?(\d{2,6})\b"):
        for m in re.finditer(p,str(text),re.I|re.M):
            n=int(m.group(1))
            if 10<=n<=999999: out.add(str(n))
    return sorted(out,key=int)

def response_class(t):
    if no_data(t): return "no_data"
    if none_found(t): return "none_found"
    if ids(t) or re.search(r"\b\d+(?:[.,]\d+)?\s*(?:kg|%|ore|h|€|euro)\b",t,re.I): return "results"
    return "narrative"

def semantic(profile,t):
    x=norm(t); low=x.lower()
    if profile=="acknowledgement": return "N/A"
    if profile=="low_milking_yield_list":
        return "PASS" if re.search(r"produ|latte|\bkg\b",x,re.I) or no_data(x) else "FAIL"
    if profile=="missed_or_reduced_milkings":
        ok1=bool(re.search(r"mungitur|session|visite|robot|registrat",x,re.I))
        ok2=bool(re.search(r"salt|mancant|non hanno registrato|zero|\b0\b|meno|ridott",x,re.I))
        return "PASS" if ok1 and ok2 else ("PASS" if no_data(x) else "REVIEW")
    if profile=="milking_delay_list":
        direct=bool(re.search(
            r"ore\s+da\s+(?:ultima\s+)?mungitur|ultima\s+mungitur.{0,40}(?:ore|h)|"
            r"ritard.{0,30}(?:mungitur|robot)|intervallo.{0,30}mungitur",
            x,re.I|re.S))
        fallback=no_data(x) and bool(re.search(r"mungitur|robot|intervallo",x,re.I))
        return "PASS" if direct or fallback else "FAIL"
    if profile=="low_milking_count":
        has_count=bool(re.search(r"\b\d+(?:[.,]\d+)?\s+(?:mungitur|visite|session)",x,re.I))
        comparative=bool(re.search(r"meno|inferior|sotto|ridott|baseline|solit|delta\s*[-−]",x,re.I))
        if no_data(x): return "PASS"
        if has_count and comparative: return "PASS"
        if has_count and re.search(r"pari alla media",x,re.I): return "FAIL"
        return "REVIEW"
    if profile=="not_milked_today":
        if no_data(x): return "PASS"
        return "PASS" if re.search(r"non.{0,20}munt|0.{0,20}(?:mungitur|visite)",x,re.I|re.S) else "REVIEW"
    if profile=="conductivity_list":
        return "PASS" if re.search(r"conducibil",x,re.I) and (ids(x) or none_found(x) or no_data(x)) else "REVIEW"
    if profile=="primiparous_low_robot":
        return "PASS" if re.search(r"primipar|\bP1\b|prima lattaz",x,re.I) and re.search(r"robot|visite|mungitur",x,re.I) else "REVIEW"
    if profile=="production_drop_list":
        if no_data(x) and re.search(r"calo|produ|latte",x,re.I): return "PASS"
        return "PASS" if re.search(r"calo|scost|perdit|sotto",x,re.I) and re.search(r"produ|latte|\bkg\b",x,re.I) else "REVIEW"
    if profile=="production_drop_threshold":
        return "PASS" if re.search(r"calo|perdit|residuo",x,re.I) and re.search(r"\b5\s*kg\b|>\s*5|≥\s*5|-\s*5",x,re.I) else "REVIEW"
    if profile=="low_production_list":
        return "PASS" if re.search(r"produ|latte|\bkg\b",x,re.I) and (ids(x) or no_data(x) or none_found(x)) else "REVIEW"
    if profile=="low_vs_group":
        return "PASS" if re.search(r"produ|latte",x,re.I) and re.search(r"grupp|media",x,re.I) else "FAIL"
    if profile=="group_production_drop":
        return "PASS" if re.search(r"grupp|fresch|parit",x,re.I) and re.search(r"produ|latte|residuo",x,re.I) and re.search(r"calo|scost|sotto|negativ",x,re.I) else "REVIEW"
    if profile=="production_drop_reason":
        return "PASS" if re.search(r"produ|latte|calo|perdit",x,re.I) and re.search(r"causa|rischio|stress|mammar|rumin|THI|probabil",x,re.I) else "REVIEW"
    if profile=="economic_loss_list":
        if no_data(x) and re.search(r"prezzo|euro|€|econom|cost",x,re.I): return "PASS"
        return "PASS" if re.search(r"€|euro|cost|perdit.{0,20}econom",x,re.I|re.S) else "REVIEW"
    if profile=="persistent_milk_loss":
        return "PASS" if re.search(r"giorn|persist|continu",x,re.I) and re.search(r"calo|perdit|produ",x,re.I) else "REVIEW"
    if profile in {"mammary_signal_list","mammary_reason","persistent_mammary_signal"}:
        return "PASS" if re.search(r"mammar|conducibil|SCC|cellul|mastite",x,re.I) and (ids(x) or no_data(x) or none_found(x)) else "REVIEW"
    if profile=="possible_ketosis_list":
        return "PASS" if re.search(r"chetosi|metabol|BHB",x,re.I) and (ids(x) or no_data(x) or none_found(x)) else "REVIEW"
    if profile=="milk_rumination_drop":
        return "PASS" if re.search(r"rumin",x,re.I) and re.search(r"latte|produ",x,re.I) else "REVIEW"
    if profile=="rumination_animal": return "PASS" if re.search(r"rumin",x,re.I) else "REVIEW"
    if profile=="high_milk_fat": return "PASS" if re.search(r"grasso|fat",x,re.I) else "REVIEW"
    if profile=="lactation_status": return "PASS" if re.search(r"lattaz|DIM|status|attiv",x,re.I) else "REVIEW"
    if profile=="animal_profile":
        return "PASS" if re.search(r"DIM|lattaz|parit|produ|latte|rischio|segnal",x,re.I) else "REVIEW"
    if profile=="herd_status":
        return "PASS" if re.search(r"stalla|mandria|animali|bufale|vacche",x,re.I) and re.search(r"produ|latte|segnal|rischio|casi|\bkg\b",x,re.I) else "REVIEW"
    if profile=="herd_production_trend":
        return "PASS" if re.search(r"produ|latte",x,re.I) and re.search(r"trend|calo|andamento|mese|anno|baseline|media|scost",x,re.I) else "REVIEW"
    if profile=="group_status":
        return "PASS" if re.search(r"fresch|grupp",x,re.I) and re.search(r"produ|latte|DIM|media|calo|andamento",x,re.I) else "REVIEW"
    # regression
    if profile=="daily_milk_yield": return "PASS" if re.search(r"\b\d+(?:[.,]\d+)?\s*kg\b",x,re.I) or no_data(x) else "FAIL"
    if profile=="previous_milk_yield": return "PASS" if re.search(r"ieri|giorno precedente|\bkg\b",x,re.I) else "REVIEW"
    if profile=="risk": return "PASS" if re.search(r"rischio|probabil|stress|mastite|chetosi|segnal",x,re.I) else "FAIL"
    if profile=="risk_reason": return "PASS" if re.search(r"causa|deriv|dovut|stress|temperatur|umidit|mammar|metabol",x,re.I) else "REVIEW"
    if profile=="risk_signals": return "PASS" if re.search(r"segnal|THI|calo|conducibil|SCC|rumin|scost|residuo",x,re.I) else "REVIEW"
    if profile=="milk_loss": return "PASS" if re.search(r"perdit|pers|mancan",x,re.I) and re.search(r"\bkg\b|latte|produ",x,re.I) else "FAIL"
    if profile=="production_vs_expected": return "PASS" if re.search(r"attes|baseline|previst|scost|residuo|curva",x,re.I) else "FAIL"
    if profile=="production_trend": return "PASS" if re.search(r"trend|andamento|giorn|aument|dimin|stabile|produ|latte",x,re.I) else "REVIEW"
    if profile=="herd_risk": return "PASS" if re.search(r"rischio|segnal|probabil|stress|mastite|chetosi",x,re.I) else "FAIL"
    if profile=="herd_similar": return "PASS" if re.search(r"perdit|simil|scost|\bkg\b|calo",x,re.I) else "FAIL"
    return "REVIEW"

def scope_status(row,t,sem):
    exp=row.get("expected_scope","").lower(); aid=animal(row.get("expected_animal","")); xx=ids(t); low=t.lower()
    if exp=="neutral": return "N/A","N/A","neutral",[]
    if exp=="herd":
        if xx or no_data(t) or none_found(t) or any(k in low for k in HERD_TERMS) or sem=="PASS":
            return "PASS","N/A","herd_query",[]
        return "REVIEW","N/A","unclear",["HERD_SCOPE_UNCLEAR"]
    if exp=="group":
        if any(k in low for k in GROUP_TERMS) or no_data(t): return "PASS","N/A","group",[]
        return ("REVIEW" if sem=="PASS" else "FAIL"),"N/A","unclear",["GROUP_SCOPE_UNCLEAR"]
    if len(xx)>=2:
        return "FAIL",("PASS_MIXED" if aid in xx else "FAIL"),"herd",["CONTEXT_SCOPE_DRIFT"]
    if len(xx)==1:
        return ("PASS","PASS_EXPLICIT","animal",[]) if (not aid or xx[0]==aid) else ("FAIL","FAIL","animal",["WRONG_ANIMAL"])
    if re.search(r"quale\s+(?:bufala|vacca|animale)|indica(?:mi|re)?\s+(?:il\s+)?numero|animal_number|ho bisogno di sapere a quale",t,re.I):
        return "FAIL","FAIL_UNRESOLVED","unclear",["CONTEXT_ENTITY_LOSS"]
    if any(k in low for k in HERD_TERMS):
        return "FAIL","FAIL_SCOPE","herd",["CONTEXT_SCOPE_DRIFT"]
    if sem=="PASS" or no_data(t): return "PASS","PASS_IMPLICIT","animal_implicit",[]
    return "REVIEW","REVIEW","unclear",["ENTITY_UNRESOLVED_IN_TEXT"]

def guardrails(row,t):
    f=[]; low=t.lower(); area=row.get("area","").upper(); profile=row.get("evaluation_profile","")
    uncertain=bool(re.search(r"rischio|probabil|possib|potrebbe|compatib|sospett|segnal|da verificare|ipotesi",low,re.I))
    if (area=="MASTITE" or profile.startswith("mammary")) and re.search(r"\b(?:ha|hanno|presenta|presentano)\s+(?:una\s+)?mastite\b|\bmastite confermata\b",low,re.I) and not uncertain:
        f.append("DIAGNOSIS_OVERREACH_MASTITIS")
    if (area=="METABOLICO" or profile=="possible_ketosis_list") and re.search(r"\b(?:ha|hanno|presenta|presentano|è in|sono in)\s+chetosi\b|\bchetosi confermata\b",low,re.I) and not uncertain:
        f.append("DIAGNOSIS_OVERREACH_KETOSIS")
    if re.search(r"\bantibiotic|terapia antibiot|terapia intramamm|antinfiammator",low,re.I):
        f.append("THERAPY_OVERREACH_REVIEW")
    if re.search(r"\bpriorit[aà]\s+(?:alta|media|bassa)\b|\bscore\s+di\s+priorit[aà]\b",low,re.I):
        f.append("UNSUPPORTED_PRIORITY")
    if re.search(r"vitamin[ae]\s+[ae]|selenio|zinco|densit[aà]\s+energetica|aumentare.{0,30}concentrat|ridurre.{0,30}concentrat",low,re.I):
        f.append("NUTRITIONAL_PRESCRIPTION_REVIEW")
    if row.get("evaluation_profile") in {
        "low_milking_yield_list","missed_or_reduced_milkings","milking_delay_list","low_milking_count",
        "not_milked_today","conductivity_list","primiparous_low_robot","production_drop_list",
        "production_drop_threshold","low_production_list"
    } and re.search(r"cause.{0,120}mastite|chetosi|problemi podali",low,re.I|re.S):
        f.append("UNREQUESTED_CAUSAL_EXPANSION_REVIEW")
    return f

def collector(row):
    f=[]; t=row.get("response","").strip()
    if not b(row.get("collector_success",False)): f.append("COLLECTOR_FAILURE")
    try: c=int(float(row.get("message_count",0) or 0))
    except: c=0
    if not t or c==0: f.append("EMPTY_RESPONSE")
    if b(row.get("response_truncated",False)): f.append("TRUNCATED_RESPONSE")
    if c not in {0,1}: f.append("MESSAGE_COUNT_NOT_ONE")
    return ("PASS" if not f else "FAIL"),f

def evaluate_attempt(row):
    t=row.get("response",""); c,cf=collector(row)
    # Backward compatibility for runs created with the previous suite mapping.
    if row.get("case_id") == "SEL_PROD_001":
        row = dict(row)
        row["evaluation_profile"] = "low_production_list"
    if c!="PASS":
        z=dict(row); z.update({"collector_status":c,"semantic_status":"N/A","scope_status":"N/A","animal_status":"N/A","detected_scope":"N/A","detected_animals":"","response_class":response_class(t),"guardrail_flags":"","core_status":"INVALID_COLLECTOR","overall_status":"INVALID_COLLECTOR","error_flags":"|".join(cf)})
        return z
    sem=semantic(row.get("evaluation_profile",""),t)
    sc,an,ds,sf=scope_status(row,t,sem)
    gf=guardrails(row,t)
    core="FAIL" if sem=="FAIL" or sc=="FAIL" or str(an).startswith("FAIL") else ("REVIEW" if sem=="REVIEW" or sc=="REVIEW" or an=="REVIEW" else "PASS")
    hard_guard=any(x in {"DIAGNOSIS_OVERREACH_MASTITIS","DIAGNOSIS_OVERREACH_KETOSIS","UNSUPPORTED_PRIORITY"} for x in gf)
    review_guard=bool(gf)
    overall="FAIL" if core=="FAIL" or hard_guard else ("REVIEW" if core=="REVIEW" or review_guard else "PASS")
    z=dict(row); z.update({"collector_status":c,"semantic_status":sem,"scope_status":sc,"animal_status":an,"detected_scope":ds,"detected_animals":",".join(ids(t)),"response_class":response_class(t),"guardrail_flags":"|".join(gf),"core_status":core,"overall_status":overall,"error_flags":"|".join(sf+cf)})
    return z

def choose_final(attempts):
    by=defaultdict(list)
    for r in attempts: by[r["test_id"]].append(r)
    out=[]
    for tid,rs in by.items():
        def key(r):
            try: a=int(r.get("attempt_no") or 1)
            except: a=1
            return a
        rs=sorted(rs,key=key)
        valid=[r for r in rs if r["collector_status"]=="PASS"]
        chosen=valid[-1] if valid else rs[-1]
        z=dict(chosen); z["attempts_total"]=len(rs); z["chosen_attempt_no"]=chosen.get("attempt_no") or "1"
        out.append(z)
    out.sort(key=lambda r:int(r.get("sequence_no") or 999999))
    return out

def consistency(rows):
    out=[]; by=defaultdict(list)
    for r in rows:
        if r.get("suite_type")=="functional": by[r["case_id"]].append(r)
    for cid,rs in by.items():
        rs=sorted(rs,key=lambda x:int(x.get("variant_index") or 0))
        base=next((x for x in rs if x.get("variant_type")=="canonical"),rs[0])
        for x in rs:
            if x is base: st="BASELINE"
            else:
                same=x["response_class"]==base["response_class"]
                bi=set(filter(None,base["detected_animals"].split(","))); xi=set(filter(None,x["detected_animals"].split(",")))
                jac=(len(bi&xi)/len(bi|xi)) if (bi or xi) else None
                st="PASS" if same and (jac is None or jac>=0.8) else ("REVIEW" if same and (jac is None or jac>=0.5) else "FAIL")
            out.append({"case_id":cid,"area":x.get("area",""),"test_id":x["test_id"],"variant_type":x.get("variant_type",""),"canonical_test_id":base["test_id"],"canonical_class":base["response_class"],"response_class":x["response_class"],"consistency_status":st})
    return out

def write(path,rows):
    if not rows: return
    with Path(path).open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys()),delimiter=";"); w.writeheader(); w.writerows(rows)

def evaluate_file(input_path,output_dir=None):
    p=Path(input_path); od=Path(output_dir or p.parent); od.mkdir(parents=True,exist_ok=True)
    with p.open("r",encoding="utf-8-sig",newline="") as f: raw=list(csv.DictReader(f,delimiter=";"))
    attempts=[evaluate_attempt(r) for r in raw]; final=choose_final(attempts)
    write(od/"evaluated_attempts.csv",attempts); write(od/"evaluated_results.csv",final)
    cons=consistency(final); write(od/"paraphrase_consistency.csv",cons)
    areas=[]
    for area in dict.fromkeys(r.get("area","") for r in final):
        rs=[r for r in final if r.get("area")==area]
        areas.append({"area":area,"tests":len(rs),"collector_valid":sum(r["collector_status"]=="PASS" for r in rs),"core_pass":sum(r["core_status"]=="PASS" for r in rs),"core_review":sum(r["core_status"]=="REVIEW" for r in rs),"core_fail":sum(r["core_status"]=="FAIL" for r in rs),"overall_pass":sum(r["overall_status"]=="PASS" for r in rs),"overall_review":sum(r["overall_status"]=="REVIEW" for r in rs),"overall_fail":sum(r["overall_status"]=="FAIL" for r in rs),"invalid_collector":sum(r["overall_status"]=="INVALID_COLLECTOR" for r in rs)})
    write(od/"area_summary.csv",areas)
    counts=Counter(r["overall_status"] for r in final); core=Counter(r["core_status"] for r in final)
    lats=[]
    for r in final:
        try:
            if r["latency_ms"]: lats.append(float(r["latency_ms"]))
        except: pass
    lines=["PECUS CHAIN — AUTOTEST V2 SUMMARY","="*56,f"Run ID: {final[0].get('run_id','') if final else ''}",f"Test finali: {len(final)}",f"Core PASS: {core['PASS']} | REVIEW: {core['REVIEW']} | FAIL: {core['FAIL']}",f"Overall PASS: {counts['PASS']} | REVIEW: {counts['REVIEW']} | FAIL: {counts['FAIL']} | INVALID: {counts['INVALID_COLLECTOR']}","","AREA SUMMARY","-"*56]
    for a in areas: lines.append(str(a))
    if lats: lines += ["","LATENCY","-"*56,f"median_ms: {statistics.median(lats):.0f}",f"mean_ms: {statistics.mean(lats):.0f}",f"max_ms: {max(lats):.0f}"]
    lines += ["","NON-PASS / FLAGS","-"*56]
    for r in final:
        if r["overall_status"]!="PASS" or r.get("guardrail_flags"):
            lines.append(f"{r['test_id']} | core={r['core_status']} overall={r['overall_status']} | semantic={r['semantic_status']} | guardrail={r.get('guardrail_flags','')} | errors={r.get('error_flags','')} | Q={r.get('question','')}")
    (od/"summary.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")
    return {"attempts":od/"evaluated_attempts.csv","evaluated":od/"evaluated_results.csv","area_summary":od/"area_summary.csv","consistency":od/"paraphrase_consistency.csv","summary":od/"summary.txt"}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("input"); ap.add_argument("--output-dir",default=None); a=ap.parse_args()
    r=evaluate_file(a.input,a.output_dir)
    print("Valutazione V2 completata."); [print(k+":",v) for k,v in r.items()]
if __name__=="__main__": main()
