from pathlib import Path
import csv

OUTPUT = Path("tests/benchmark_v2.csv")
OUTPUT.parent.mkdir(parents=True, exist_ok=True)

rows = [
    # ================================================================
    # A — CONTEXT DECAY
    # Animal 3118 is named once, then progressively omitted.
    # ================================================================
    ["A_DECAY_001", "A_CONTEXT_DECAY", 1, "anchor", "animal_profile",
     "descrivi la 3118", True, "3118", "animal", "anchor"],
    ["A_DECAY_002", "A_CONTEXT_DECAY", 2, "implicit_followup", "daily_milk_yield",
     "quanto produce oggi?", False, "3118", "animal", "context_probe"],
    ["A_DECAY_003", "A_CONTEXT_DECAY", 3, "implicit_followup", "previous_milk_yield",
     "e ieri?", False, "3118", "animal", "context_probe"],
    ["A_DECAY_004", "A_CONTEXT_DECAY", 4, "implicit_followup", "risk",
     "ha qualche rischio?", False, "3118", "animal", "context_probe"],
    ["A_DECAY_005", "A_CONTEXT_DECAY", 5, "implicit_followup", "risk_reason",
     "da cosa deriva?", False, "3118", "animal", "context_probe"],
    ["A_DECAY_006", "A_CONTEXT_DECAY", 6, "implicit_followup", "risk_signals",
     "quali segnali lo indicano?", False, "3118", "animal", "context_probe"],
    ["A_DECAY_007", "A_CONTEXT_DECAY", 7, "implicit_followup", "milk_loss",
     "quanto latte sta perdendo?", False, "3118", "animal", "context_probe"],
    ["A_DECAY_008", "A_CONTEXT_DECAY", 8, "implicit_followup", "production_vs_expected",
     "come va rispetto al previsto?", False, "3118", "animal", "context_probe"],
    ["A_DECAY_009", "A_CONTEXT_DECAY", 9, "implicit_followup", "daily_milk_yield",
     "e nelle ultime 24 ore quanto ha prodotto?", False, "3118", "animal", "context_probe"],
    ["A_DECAY_010", "A_CONTEXT_DECAY", 10, "implicit_followup", "production_vs_expected",
     "quanto è distante dall'atteso?", False, "3118", "animal", "context_probe"],
    ["A_DECAY_011", "A_CONTEXT_DECAY", 11, "implicit_followup", "risk",
     "qual è il rischio principale adesso?", False, "3118", "animal", "context_probe"],
    ["A_DECAY_012", "A_CONTEXT_DECAY", 12, "implicit_followup", "daily_milk_yield",
     "quindi oggi quanti kg ha fatto?", False, "3118", "animal", "context_probe"],

    # ================================================================
    # B — SCOPE SWITCH / RECOVERY
    # Test whether active animal survives temporary herd-scope questions.
    # ================================================================
    ["B_SCOPE_001", "B_SCOPE_RECOVERY", 1, "anchor", "animal_profile",
     "descrivi la 3118", True, "3118", "animal", "anchor"],
    ["B_SCOPE_002", "B_SCOPE_RECOVERY", 2, "implicit_followup", "daily_milk_yield",
     "quanto produce oggi?", False, "3118", "animal", "context_probe"],
    ["B_SCOPE_003", "B_SCOPE_RECOVERY", 3, "scope_switch", "herd_risk",
     "quali bufale sono a rischio oggi?", False, "", "herd", "scope_switch"],
    ["B_SCOPE_004", "B_SCOPE_RECOVERY", 4, "scope_recovery", "daily_milk_yield",
     "e quanto produce oggi?", False, "3118", "animal", "recovery_probe"],
    ["B_SCOPE_005", "B_SCOPE_RECOVERY", 5, "scope_recovery", "previous_milk_yield",
     "e ieri?", False, "3118", "animal", "recovery_probe"],
    ["B_SCOPE_006", "B_SCOPE_RECOVERY", 6, "scope_switch", "herd_similar",
     "quali altre bufale hanno una perdita simile?", False, "", "herd", "scope_switch"],
    ["B_SCOPE_007", "B_SCOPE_RECOVERY", 7, "scope_recovery", "risk",
     "e il suo rischio qual è?", False, "3118", "animal", "recovery_probe"],
    ["B_SCOPE_008", "B_SCOPE_RECOVERY", 8, "scope_recovery", "production_vs_expected",
     "tornando a lei, quanto è distante dall'atteso?", False, "3118", "animal", "recovery_probe"],
    ["B_SCOPE_009", "B_SCOPE_RECOVERY", 9, "scope_recovery", "risk_signals",
     "e quali segnali lo spiegano?", False, "3118", "animal", "recovery_probe"],

    # ================================================================
    # C — ENTITY SWITCHING
    # Track current and previous animal while switching 3118 <-> 2516.
    # ================================================================
    ["C_ENTITY_001", "C_ENTITY_SWITCH", 1, "anchor", "animal_profile",
     "descrivi la 3118", True, "3118", "animal", "anchor"],
    ["C_ENTITY_002", "C_ENTITY_SWITCH", 2, "implicit_followup", "daily_milk_yield",
     "quanto produce oggi?", False, "3118", "animal", "entity_probe"],
    ["C_ENTITY_003", "C_ENTITY_SWITCH", 3, "entity_switch", "animal_profile",
     "descrivi la 2516", True, "2516", "animal", "entity_switch"],
    ["C_ENTITY_004", "C_ENTITY_SWITCH", 4, "implicit_followup", "daily_milk_yield",
     "quanto produce oggi?", False, "2516", "animal", "entity_probe"],
    ["C_ENTITY_005", "C_ENTITY_SWITCH", 5, "implicit_followup", "previous_milk_yield",
     "e ieri?", False, "2516", "animal", "entity_probe"],
    ["C_ENTITY_006", "C_ENTITY_SWITCH", 6, "entity_switch", "animal_profile",
     "e invece la 3118?", True, "3118", "animal", "entity_switch"],
    ["C_ENTITY_007", "C_ENTITY_SWITCH", 7, "implicit_followup", "daily_milk_yield",
     "quanto produce oggi?", False, "3118", "animal", "entity_probe"],
    ["C_ENTITY_008", "C_ENTITY_SWITCH", 8, "implicit_followup", "risk",
     "e il suo rischio?", False, "3118", "animal", "entity_probe"],
    ["C_ENTITY_009", "C_ENTITY_SWITCH", 9, "entity_switch", "animal_profile",
     "torna alla 2516", True, "2516", "animal", "entity_switch"],
    ["C_ENTITY_010", "C_ENTITY_SWITCH", 10, "implicit_followup", "daily_milk_yield",
     "e oggi quanto produce?", False, "2516", "animal", "entity_probe"],
    ["C_ENTITY_011", "C_ENTITY_SWITCH", 11, "previous_entity_recall", "animal_profile",
     "e l'altra invece?", False, "3118", "animal", "previous_entity_probe"],
    ["C_ENTITY_012", "C_ENTITY_SWITCH", 12, "implicit_followup", "daily_milk_yield",
     "quanto produce?", False, "3118", "animal", "entity_probe"],

    # ================================================================
    # D — CONVERSATIONAL NOISE
    # Neutral utterances must not clear the active animal.
    # ================================================================
    ["D_NOISE_001", "D_NOISE_RETENTION", 1, "anchor", "animal_profile",
     "descrivi la 3118", True, "3118", "animal", "anchor"],
    ["D_NOISE_002", "D_NOISE_RETENTION", 2, "noise", "acknowledgement",
     "ok", False, "", "neutral", "noise"],
    ["D_NOISE_003", "D_NOISE_RETENTION", 3, "noise", "acknowledgement",
     "capito", False, "", "neutral", "noise"],
    ["D_NOISE_004", "D_NOISE_RETENTION", 4, "noise", "acknowledgement",
     "grazie", False, "", "neutral", "noise"],
    ["D_NOISE_005", "D_NOISE_RETENTION", 5, "post_noise_probe", "daily_milk_yield",
     "quanto produce oggi?", False, "3118", "animal", "noise_recovery_probe"],
    ["D_NOISE_006", "D_NOISE_RETENTION", 6, "noise", "acknowledgement",
     "bene", False, "", "neutral", "noise"],
    ["D_NOISE_007", "D_NOISE_RETENTION", 7, "post_noise_probe", "previous_milk_yield",
     "e ieri?", False, "3118", "animal", "noise_recovery_probe"],
    ["D_NOISE_008", "D_NOISE_RETENTION", 8, "noise", "acknowledgement",
     "ok", False, "", "neutral", "noise"],
    ["D_NOISE_009", "D_NOISE_RETENTION", 9, "post_noise_probe", "risk",
     "ha qualche rischio?", False, "3118", "animal", "noise_recovery_probe"],
    ["D_NOISE_010", "D_NOISE_RETENTION", 10, "noise", "acknowledgement",
     "grazie", False, "", "neutral", "noise"],
    ["D_NOISE_011", "D_NOISE_RETENTION", 11, "post_noise_probe", "risk_reason",
     "da cosa deriva?", False, "3118", "animal", "noise_recovery_probe"],
]

headers = [
    "test_id",
    "scenario",
    "scenario_turn",
    "test_family",
    "intent",
    "question",
    "animal_explicit",
    "expected_animal",
    "expected_scope",
    "probe_type",
]

with OUTPUT.open("w", encoding="utf-8-sig", newline="") as f:
    writer = csv.writer(f, delimiter=";")
    writer.writerow(headers)
    writer.writerows(rows)

print("Benchmark V2 creato:", OUTPUT)
print("Test totali:", len(rows))
print("Scenari: A_CONTEXT_DECAY, B_SCOPE_RECOVERY, C_ENTITY_SWITCH, D_NOISE_RETENTION")
