# chatbot_client.py

class ChatbotClient:

    def send(self, message, conversation_id):
        raise NotImplementedError