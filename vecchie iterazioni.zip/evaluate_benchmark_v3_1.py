from __future__ import annotations

import argparse
import csv
import re
import statistics
from collections import Counter, defaultdict
from pathlib import Path


def as_bool(value):
    return str(value).strip().lower() in {"true", "1", "yes", "si", "sì"}


def normalize_animal(value):
    value = str(value or "").strip()
    if not value or value.lower() == "nan":
        return ""
    try:
        return str(int(float(value.replace(",", "."))))
    except ValueError:
        return value


def extract_animals(text):
    ids = set()
    for pattern in (
        r"#\s*(\d{3,6})\b",
        r"\b(?:bufala|bovina|vacca|animale)\s+#?(\d{3,6})\b",
        r"^\s*#?(\d{3,6})\b",
    ):
        for match in re.finditer(pattern, str(text), flags=re.I | re.M):
            n = int(match.group(1))
            if 100 <= n <= 999999:
                ids.add(str(n))
    return sorted(ids, key=int)


def primary_text(text, limit=650):
    return re.sub(r"\s+", " ", str(text or "")).strip()[:limit]


def has_no_today_data(text):
    t = str(text).lower()
    patterns = (
        r"nessun[a-z]*\s+(?:registrazione|dato|lettura)",
        r"non\s+(?:è|e)\s+(?:ancora\s+)?(?:presente|disponibile|registrat)",
        r"non\s+risulta\s+alcun",
        r"produzione\s+odierna\s+non\s+ancora\s+registrata",
        r"non\s+è\s+possibile\s+indicare",
        r"non\s+ci\s+sono\s+(?:ancora\s+)?registrazioni",
        r"non\s+ha\s+ancora\s+una\s+registrazione",
        r"nessuna\s+registrazione",
        r"non\s+è\s+disponibile\s+il\s+valore",
    )
    return any(re.search(p, t, flags=re.I) for p in patterns)


def intent_status(intent, response, expected_scope):
    text = str(response)
    low = text.lower()

    if intent == "acknowledgement":
        return "N/A"

    if intent == "animal_profile":
        score = 0
        if re.search(r"\bDIM\b|\bL\d\b|\bP\d\b|lattazion", text, re.I):
            score += 1
        if re.search(r"produ|\bkg\b", text, re.I):
            score += 1
        if re.search(r"rischio|stress|mastite|chetosi|probabilit", text, re.I):
            score += 1
        return "PASS" if score >= 1 else "REVIEW"

    if intent == "daily_milk_yield":
        if re.search(r"\b\d+(?:[.,]\d+)?\s*kg\b", text, re.I):
            return "PASS"
        if has_no_today_data(text):
            return "PASS"
        return "FAIL"

    if intent == "previous_milk_yield":
        if re.search(r"ieri|30[-‑/]08|30\s*ago|30 agosto|giorno precedente", text, re.I):
            return "PASS"
        return "REVIEW"

    if intent == "risk":
        return "PASS" if re.search(
            r"rischio|probabilit|stress da cal|mastite|chetosi", text, re.I
        ) else "FAIL"

    if intent == "risk_reason":
        return "PASS" if re.search(
            r"causa|deriv|dovut|stress da cal|temperatur|umidit|mastite", text, re.I
        ) else "REVIEW"

    if intent == "risk_signals":
        return "PASS" if re.search(
            r"segnal|calo produzione|ore di caldo|residuo|THI|conducibilit|scostamento",
            text, re.I
        ) else "REVIEW"

    if intent == "milk_loss":
        return "PASS" if re.search(
            r"perdit.{0,80}\bkg\b|\bkg\b.{0,80}perdit", text, re.I | re.S
        ) else "FAIL"

    if intent == "production_vs_expected":
        return "PASS" if re.search(
            r"attes|baseline|scostamento|residuo|previst", text, re.I
        ) else "FAIL"

    if intent == "production_trend":
        return "PASS" if re.search(
            r"ultimi\s+\d+\s+giorni|andamento|trend|\b24 ago\b|\b25 ago\b|\b26 ago\b",
            text, re.I
        ) else "REVIEW"

    if intent == "herd_risk":
        return "PASS" if re.search(
            r"rischio|stress|mastite|chetosi|probabilit", text, re.I
        ) else "FAIL"

    if intent == "herd_similar":
        return "PASS" if re.search(
            r"perdit|simil|stessa fascia|scostamento|\bkg\b", text, re.I
        ) else "FAIL"

    return "REVIEW"


def context_status(row, response, intent_result):
    expected_scope = row["expected_scope"]
    expected_animal = normalize_animal(row.get("expected_animal", ""))
    ids = extract_animals(response)
    primary = primary_text(response, 260)

    if expected_scope == "neutral":
        return "N/A", "N/A", "N/A", []

    # Herd/list query: returning one matching animal is still a correct group query.
    if expected_scope == "herd":
        if ids:
            return "PASS", "N/A", "herd_query", []
        if re.search(r"mandria|bufale|animali|capi|stalla", primary, re.I):
            return "PASS", "N/A", "herd_query", []
        return "REVIEW", "N/A", "unclear", ["HERD_RESULT_UNCLEAR"]

    # Animal query.
    if len(ids) >= 2:
        return "FAIL", (
            "PASS_MIXED" if expected_animal in ids else "FAIL"
        ), "herd", ["CONTEXT_SCOPE_DRIFT"]

    if len(ids) == 1:
        if ids[0] == expected_animal:
            return "PASS", "PASS_EXPLICIT", "animal", []
        return "FAIL", "FAIL", "animal", ["WRONG_ANIMAL"]

    # No ID in the answer. Distinguish genuine context loss from normal implicit continuation.
    if re.search(
        r"ho bisogno di sapere a quale bufala|indica(?:re)? il numero|"
        r"quale bufala ti riferisci|animal_number",
        primary,
        re.I,
    ):
        return "FAIL", "FAIL_UNRESOLVED", "unclear", ["CONTEXT_ENTITY_LOSS"]

    if re.search(
        r"produzione totale|da\s+\d+\s+bufale|nella stalla|della mandria|"
        r"le tue bufale|tutte le bufale",
        primary,
        re.I,
    ):
        return "FAIL", "FAIL_SCOPE", "herd", ["CONTEXT_SCOPE_DRIFT"]

    # In a real conversation the bot does not need to repeat the animal ID every turn.
    if intent_result == "PASS":
        return "PASS", "PASS_IMPLICIT", "animal_implicit", []

    return "REVIEW", "REVIEW", "unclear", ["ENTITY_NOT_EXPLICIT"]


def collector_status(row):
    flags = []
    response = str(row.get("response", "") or "").strip()

    if not as_bool(row.get("collector_success", False)):
        flags.append("COLLECTOR_FAILURE")

    try:
        message_count = int(float(row.get("message_count", 0)))
    except Exception:
        message_count = 0

    if not response or message_count == 0:
        flags.append("EMPTY_RESPONSE")

    if as_bool(row.get("response_truncated", False)):
        flags.append("TRUNCATED_RESPONSE")

    if message_count != 1:
        flags.append("MESSAGE_COUNT_NOT_ONE")

    return ("PASS" if not flags else "FAIL"), flags


def evaluate(rows):
    evaluated = []

    for row in rows:
        response = str(row.get("response", "") or "")
        collector, collector_flags = collector_status(row)

        if collector != "PASS":
            record = dict(row)
            record.update({
                "collector_status": collector,
                "intent_correct": "N/A",
                "scope_correct": "N/A",
                "animal_correct": "N/A",
                "detected_scope": "N/A",
                "detected_animals": "",
                "context_correct": "N/A",
                "overall_status": "INVALID_COLLECTOR",
                "error_flags": "|".join(collector_flags),
            })
            evaluated.append(record)
            continue

        intent = intent_status(row["intent"], response, row["expected_scope"])
        scope, animal, detected_scope, context_flags = context_status(
            row, response, intent
        )

        if row["expected_scope"] == "neutral":
            overall = "PASS"
            context = "N/A"
        else:
            context = "PASS" if scope == "PASS" and animal != "FAIL" else (
                "FAIL" if scope == "FAIL" or str(animal).startswith("FAIL") else "REVIEW"
            )

            if intent == "FAIL" or context == "FAIL":
                overall = "FAIL"
            elif intent == "REVIEW" or context == "REVIEW":
                overall = "REVIEW"
            else:
                overall = "PASS"

        record = dict(row)
        record.update({
            "collector_status": collector,
            "intent_correct": intent,
            "scope_correct": scope,
            "animal_correct": animal,
            "detected_scope": detected_scope,
            "detected_animals": ",".join(extract_animals(response)),
            "context_correct": context,
            "overall_status": overall,
            "error_flags": "|".join(context_flags),
        })
        evaluated.append(record)

    return evaluated


def scenario_metrics(rows):
    metrics = []

    for scenario in dict.fromkeys(r["scenario"] for r in rows):
        rs = [r for r in rows if r["scenario"] == scenario]
        valid = [r for r in rs if r["collector_status"] == "PASS"]
        scored = [r for r in valid if r["expected_scope"] != "neutral"]
        passes = sum(r["overall_status"] == "PASS" for r in scored)

        metrics.append({
            "scenario": scenario,
            "tests_total": len(rs),
            "collector_valid": len(valid),
            "scored": len(scored),
            "pass": passes,
            "success_pct": round(100 * passes / len(scored), 1) if scored else "",
        })

    return metrics


def headline(rows):
    result = {}

    # A: strict consecutive retention depth and later recoveries.
    a = sorted(
        [r for r in rows if r["scenario"] == "A_CONTEXT_DECAY"],
        key=lambda r: int(r["scenario_turn"]),
    )
    probes = [r for r in a if r["probe_type"] == "context_probe"]
    depth = 0
    first_failure_index = None

    for i, r in enumerate(probes):
        if r["overall_status"] == "PASS":
            depth += 1
        else:
            first_failure_index = i
            break

    result["context_retention_depth_strict"] = depth

    if first_failure_index is not None:
        after = probes[first_failure_index + 1:]
        result["context_recovery_after_first_failure"] = (
            f"{sum(r['overall_status'] == 'PASS' for r in after)}/{len(after)}"
        )
    else:
        result["context_recovery_after_first_failure"] = "N/A"

    recovery = [
        r for r in rows
        if r["probe_type"] == "recovery_probe"
    ]
    result["scope_recovery"] = (
        f"{sum(r['overall_status'] == 'PASS' for r in recovery)}/{len(recovery)}"
    )

    scope_switches = [
        r for r in rows
        if r["probe_type"] == "scope_switch"
    ]
    result["herd_scope_switch"] = (
        f"{sum(r['overall_status'] == 'PASS' for r in scope_switches)}/{len(scope_switches)}"
    )

    entity = [
        r for r in rows
        if r["probe_type"] in {"entity_probe", "previous_entity_probe"}
    ]
    result["entity_probe"] = (
        f"{sum(r['overall_status'] == 'PASS' for r in entity)}/{len(entity)}"
    )

    noise = [
        r for r in rows
        if r["probe_type"] == "noise_recovery_probe"
    ]
    result["noise_recovery"] = (
        f"{sum(r['overall_status'] == 'PASS' for r in noise)}/{len(noise)}"
    )

    para = [
        r for r in rows
        if r["probe_type"] == "paraphrase_probe"
    ]
    result["paraphrase_semantic_robustness"] = (
        f"{sum(r['overall_status'] == 'PASS' for r in para)}/{len(para)}"
    )

    # Current-day paraphrases: all questions explicitly containing oggi/odierna.
    today = [
        r for r in para
        if re.search(r"\boggi\b|odiern", r["question"], re.I)
    ]
    availability_consistent = sum(has_no_today_data(r["response"]) for r in today)
    result["today_availability_consistency"] = (
        f"{availability_consistent}/{len(today)}"
    )

    # Latest known 6.0 kg consistency when a numeric latest value is actually stated.
    numeric = [
        r for r in para
        if re.search(r"\b6[,.]0\s*kg\b", r["response"], re.I)
    ]
    result["latest_value_6kg_mentions"] = f"{len(numeric)}/{len(para)}"

    latencies = [
        float(r["latency_ms"])
        for r in rows
        if str(r.get("latency_ms", "")).strip()
    ]
    if latencies:
        result["latency_median_ms"] = round(statistics.median(latencies))
        result["latency_mean_ms"] = round(statistics.mean(latencies))
        result["latency_max_ms"] = round(max(latencies))

    return result


def write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()), delimiter=";")
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "input",
        nargs="?",
        default="results/benchmark_v3_results.csv",
    )
    parser.add_argument(
        "--output",
        default="results/benchmark_v3_1_evaluated.csv",
    )
    parser.add_argument(
        "--scenario-output",
        default="results/benchmark_v3_1_scenarios.csv",
    )
    parser.add_argument(
        "--summary",
        default="results/benchmark_v3_1_summary.txt",
    )
    args = parser.parse_args()

    with Path(args.input).open("r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f, delimiter=";"))

    if not rows:
        raise SystemExit("Nessun risultato.")

    evaluated = evaluate(rows)
    scenarios = scenario_metrics(evaluated)
    metrics = headline(evaluated)

    write_csv(Path(args.output), evaluated)
    write_csv(Path(args.scenario_output), scenarios)

    counts = Counter(r["overall_status"] for r in evaluated)

    lines = [
        "PECUS CHAIN — Benchmark V3.1 Review",
        "=" * 48,
        f"Run ID: {evaluated[0]['run_id']}",
        f"Test raccolti: {len(evaluated)}",
        f"PASS: {counts['PASS']}",
        f"REVIEW: {counts['REVIEW']}",
        f"FAIL: {counts['FAIL']}",
        f"INVALID_COLLECTOR: {counts['INVALID_COLLECTOR']}",
        "",
        "HEADLINE METRICS",
        "-" * 48,
    ]

    for key, value in metrics.items():
        lines.append(f"{key}: {value}")

    lines += ["", "SCENARIOS", "-" * 48]
    for s in scenarios:
        lines.append(
            f"{s['scenario']}: {s['pass']}/{s['scored']} "
            f"({s['success_pct']}%), collector {s['collector_valid']}/{s['tests_total']}"
        )

    lines += ["", "FAIL / REVIEW", "-" * 48]
    for r in evaluated:
        if r["overall_status"] not in {"PASS"}:
            lines.append(
                f"{r['test_id']} | {r['overall_status']} | {r['error_flags']} | "
                f"intent={r['intent_correct']} | scope={r['scope_correct']} | "
                f"animal={r['animal_correct']} | Q={r['question']}"
            )

    Path(args.summary).write_text("\n".join(lines) + "\n", encoding="utf-8")

    print("Valutati:", len(evaluated))
    print(
        "PASS=", counts["PASS"],
        "REVIEW=", counts["REVIEW"],
        "FAIL=", counts["FAIL"],
        "INVALID_COLLECTOR=", counts["INVALID_COLLECTOR"],
    )
    print("Summary:", args.summary)


if __name__ == "__main__":
    main()
