from __future__ import annotations

from playwright.sync_api import sync_playwright
from pathlib import Path
from datetime import datetime
import csv
import re
import time


BOT_NAME = "Marica Marches"

TEST_FILE = Path("tests/benchmark_v2.csv")
RESULTS_DIR = Path("results")
RESULTS_FILE = RESULTS_DIR / "benchmark_v2_results.csv"

TIMEOUT_SECONDS = 90
QUIET_SECONDS = 3
BETWEEN_QUESTIONS_SECONDS = 4
BETWEEN_SCENARIOS_SECONDS = 6

RESULTS_DIR.mkdir(parents=True, exist_ok=True)

RUN_ID = "V2_" + datetime.now().strftime("%Y%m%d_%H%M%S")


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def fingerprint(message: dict) -> tuple:
    normalized = normalize_text(message["text"])
    return (message["metadata"], normalized[:180])


def get_bot_messages(page) -> list[dict]:
    locator = page.locator(f'[data-pre-plain-text*="{BOT_NAME}:"]')
    raw_messages = []

    for i in range(locator.count()):
        element = locator.nth(i)

        try:
            text = element.inner_text().strip()
            metadata = element.get_attribute("data-pre-plain-text")

            message_id = None
            ancestor = element.locator("xpath=ancestor::*[@data-id][1]")

            if ancestor.count() > 0:
                message_id = ancestor.get_attribute("data-id")

            if text:
                raw_messages.append(
                    {
                        "message_id": message_id,
                        "metadata": metadata,
                        "text": text,
                    }
                )

        except Exception:
            pass

    # WhatsApp can expose the same message twice while its data-id settles.
    deduped = {}

    for message in raw_messages:
        key = fingerprint(message)

        if key not in deduped:
            deduped[key] = message
            continue

        existing = deduped[key]

        if message["message_id"] and not existing["message_id"]:
            existing["message_id"] = message["message_id"]

        if len(message["text"]) > len(existing["text"]):
            existing["text"] = message["text"]

    return list(deduped.values())


def expand_latest_message(page) -> bool:
    try:
        more = page.get_by_text("Leggi di più", exact=True)

        if more.count() > 0:
            more.last.click(timeout=3000)
            page.wait_for_timeout(700)
            return True

    except Exception:
        pass

    return False


def load_tests() -> list[dict]:
    with TEST_FILE.open("r", encoding="utf-8-sig", newline="") as f:
        return [
            {
                str(k).strip(): str(v).strip() if v is not None else ""
                for k, v in row.items()
            }
            for row in csv.DictReader(f, delimiter=";")
        ]


def save_result(test: dict, result: dict) -> None:
    exists = RESULTS_FILE.exists()

    with RESULTS_FILE.open("a", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f, delimiter=";")

        if not exists:
            writer.writerow(
                [
                    "run_id",
                    "test_id",
                    "scenario",
                    "scenario_turn",
                    "test_family",
                    "probe_type",
                    "intent",
                    "question",
                    "animal_explicit",
                    "expected_animal",
                    "expected_scope",
                    "response",
                    "latency_ms",
                    "message_count",
                    "response_truncated",
                    "message_ids",
                    "whatsapp_metadata",
                    "system_timestamp",
                    "collector_success",
                ]
            )

        writer.writerow(
            [
                RUN_ID,
                test["test_id"],
                test["scenario"],
                test["scenario_turn"],
                test["test_family"],
                test["probe_type"],
                test["intent"],
                test["question"],
                test["animal_explicit"],
                test["expected_animal"],
                test["expected_scope"],
                result["response"],
                result["latency_ms"] if result["latency_ms"] is not None else "",
                len(result["messages"]),
                result["truncated"],
                " | ".join(str(m["message_id"]) for m in result["messages"]),
                " | ".join(str(m["metadata"]) for m in result["messages"]),
                datetime.now().isoformat(timespec="seconds"),
                result["success"],
            ]
        )


def run_single_test(page, message_box, test: dict) -> dict:
    old_messages = get_bot_messages(page)
    old_fingerprints = {fingerprint(m) for m in old_messages}

    print()
    print("=" * 76)
    print(
        f'{test["scenario"]} | turn {test["scenario_turn"]} | '
        f'{test["test_id"]}'
    )
    print("Probe:", test["probe_type"])
    print("Intent:", test["intent"])
    print("Domanda:", test["question"])
    print("=" * 76)

    start_time = time.monotonic()

    message_box.click()
    message_box.fill(test["question"])
    message_box.press("Enter")

    print("Messaggio inviato. Attendo PECUS...")

    deadline = time.monotonic() + TIMEOUT_SECONDS
    first_response_time = None
    new_messages = []

    while time.monotonic() < deadline:
        current = get_bot_messages(page)
        current_new = [
            m for m in current if fingerprint(m) not in old_fingerprints
        ]

        if current_new:
            first_response_time = time.monotonic()
            new_messages = current_new
            break

        page.wait_for_timeout(500)

    if not new_messages:
        print("TIMEOUT: nessuna nuova risposta rilevata.")
        return {
            "response": "",
            "latency_ms": None,
            "messages": [],
            "truncated": False,
            "success": False,
        }

    latency_ms = int((first_response_time - start_time) * 1000)
    print("Prima risposta dopo:", latency_ms, "ms")

    expand_latest_message(page)

    # Wait until no new logical message appears for QUIET_SECONDS.
    stable_since = time.monotonic()
    previous_fps = None

    while True:
        page.wait_for_timeout(500)

        current = get_bot_messages(page)
        current_new = [
            m for m in current if fingerprint(m) not in old_fingerprints
        ]
        fps = {fingerprint(m) for m in current_new}

        if fps != previous_fps:
            previous_fps = fps
            stable_since = time.monotonic()

        if time.monotonic() - stable_since >= QUIET_SECONDS:
            new_messages = current_new
            break

    # Final dedupe.
    final = {}

    for message in new_messages:
        key = fingerprint(message)

        if key not in final:
            final[key] = message
            continue

        existing = final[key]

        if message["message_id"] and not existing["message_id"]:
            existing["message_id"] = message["message_id"]

        if len(message["text"]) > len(existing["text"]):
            existing["text"] = message["text"]

    final_messages = list(final.values())
    response = "\n\n".join(m["text"].strip() for m in final_messages)
    truncated = "Leggi di più" in response

    print()
    print("--- RISPOSTA PECUS ---")
    print(response)
    print("-----------------------")
    print("Messaggi logici:", len(final_messages))
    print("Troncata:", truncated)

    return {
        "response": response,
        "latency_ms": latency_ms,
        "messages": final_messages,
        "truncated": truncated,
        "success": True,
    }


def main() -> None:
    tests = load_tests()

    print("Benchmark V2")
    print("Test caricati:", len(tests))
    print("Run ID:", RUN_ID)
    print("Output:", RESULTS_FILE)

    with sync_playwright() as p:
        context = p.chromium.launch_persistent_context(
            user_data_dir="./whatsapp_profile",
            headless=False,
        )

        page = context.pages[0]

        if not page.url.startswith("https://web.whatsapp.com"):
            page.goto("https://web.whatsapp.com")

        print("\nWhatsApp avviato")
        page.wait_for_timeout(5000)

        message_box = page.locator(
            '[contenteditable="true"][role="textbox"][data-tab="10"]'
        )

        message_box.wait_for(state="visible", timeout=30000)
        print("Campo messaggio trovato")

        previous_scenario = None

        for index, test in enumerate(tests, start=1):
            current_scenario = test["scenario"]

            if previous_scenario and current_scenario != previous_scenario:
                print()
                print("#" * 76)
                print("NUOVO SCENARIO:", current_scenario)
                print("#" * 76)

                page.wait_for_timeout(BETWEEN_SCENARIOS_SECONDS * 1000)

            result = run_single_test(page, message_box, test)
            save_result(test, result)

            print(f"Salvato {index}/{len(tests)}")

            previous_scenario = current_scenario

            if index < len(tests):
                page.wait_for_timeout(BETWEEN_QUESTIONS_SECONDS * 1000)

        print()
        print("=" * 76)
        print("BENCHMARK V2 COMPLETATO")
        print("=" * 76)
        print("Run ID:", RUN_ID)
        print("Risultati:", RESULTS_FILE)

        input("\nPremi INVIO per chiudere...")
        context.close()


if __name__ == "__main__":
    main()
