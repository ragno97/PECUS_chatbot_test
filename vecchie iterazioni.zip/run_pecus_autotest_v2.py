from __future__ import annotations
from playwright.sync_api import sync_playwright
from pathlib import Path
from datetime import datetime
import argparse,csv,re,shutil,time

DEFAULT_SUITE=Path("tests/pecus_llm_current_suite_v2.csv")
DEFAULT_BOT_NAME="Marica Marches"

def norm(t): return re.sub(r"\s+"," ",str(t or "")).strip()
def parse_dt(meta):
    m=re.search(r"\[(\d{1,2}):(\d{2}),\s*(\d{1,2})/(\d{1,2})/(\d{4})\]",meta or "")
    if not m:return None
    hh,mm,dd,mo,yy=map(int,m.groups()); return datetime(yy,mo,dd,hh,mm)
def key(m): return "id:"+str(m["message_id"]) if m.get("message_id") else "fallback:"+str(m.get("metadata"))+"|"+norm(m.get("text"))[:250]

def bot_messages(page,bot):
    loc=page.locator(f'[data-pre-plain-text*="{bot}:"]'); arr=[]
    for i in range(loc.count()):
        e=loc.nth(i)
        try:
            text=e.inner_text().strip(); meta=e.get_attribute("data-pre-plain-text"); anc=e.locator("xpath=ancestor::*[@data-id][1]"); mid=anc.get_attribute("data-id") if anc.count()>0 else None
            if text: arr.append({"message_id":mid,"metadata":meta,"message_dt":parse_dt(meta),"text":text,"dom_index":i})
        except: pass
    d={}
    for m in arr:
        ck=(m["metadata"],norm(m["text"])[:220])
        if ck not in d:d[ck]=m
        else:
            if m.get("message_id") and not d[ck].get("message_id"):d[ck]["message_id"]=m["message_id"]
            if len(m["text"])>len(d[ck]["text"]):d[ck]["text"]=m["text"]
    return list(d.values())

def expand(page,mid):
    if not mid:return
    try:
        node=page.locator(f'[data-id="{mid}"]'); more=node.get_by_text("Leggi di più",exact=True)
        if node.count() and more.count(): more.last.click(timeout=3000); page.wait_for_timeout(800)
    except: pass

def load(path):
    with Path(path).open("r",encoding="utf-8-sig",newline="") as f:return [{str(k).strip():str(v).strip() if v is not None else "" for k,v in r.items()} for r in csv.DictReader(f,delimiter=";")]

def select(rows,mode):
    if mode=="smoke": return sorted([r for r in rows if r.get("suite_type")=="functional" and r.get("variant_type")=="canonical"],key=lambda r:(int(r.get("area_order") or 0),int(r.get("case_order") or 0)))
    if mode=="functional": return sorted([r for r in rows if r.get("suite_type")=="functional"],key=lambda r:int(r.get("execution_order") or 0))
    if mode=="regression":
        order={"A_CONTEXT_DECAY":1,"B_SCOPE_RECOVERY":2,"C_ENTITY_SWITCH":3,"D_NOISE_RETENTION":4,"E_PARAPHRASE_PRODUCTION":5}
        return sorted([r for r in rows if r.get("suite_type")=="regression"],key=lambda r:(order.get(r.get("scenario"),99),int(r.get("scenario_turn") or 0)))
    if mode=="all":return select(rows,"functional")+select(rows,"regression")
    raise ValueError(mode)

def candidates(page,bot,known,send_minute):
    out=[]
    for m in bot_messages(page,bot):
        if key(m) in known:continue
        if m.get("message_dt") is not None and m["message_dt"]<send_minute:continue
        out.append(m)
    return sorted(out,key=lambda m:(m.get("message_dt") or send_minute,m.get("dom_index",0)))

FIELDS=["run_id","run_mode","sequence_no","attempt_no","attempt_uid","test_id","case_id","area","suite_type","scenario","scenario_turn","block","variant_index","variant_type","variant_source","previously_executed","prior_validated","prior_result","source_case_id","source_mapping","question","evaluation_profile","expected_scope","expected_animal","input_data","expected_behavior","expected_fields","fallback","guardrail","support_current","probe_type","response","latency_ms","message_count","response_truncated","message_ids","whatsapp_metadata","send_system_timestamp","system_timestamp","collector_success","collector_note"]

def append(path,run_id,mode,seq,attempt,test,res):
    exists=path.exists(); row={k:test.get(k,"") for k in FIELDS}; row.update({"run_id":run_id,"run_mode":mode,"sequence_no":seq,"attempt_no":attempt,"attempt_uid":f"{test['test_id']}_A{attempt}","response":res["response"],"latency_ms":"" if res["latency_ms"] is None else res["latency_ms"],"message_count":len(res["messages"]),"response_truncated":res["truncated"],"message_ids":" | ".join(str(m.get("message_id")) for m in res["messages"]),"whatsapp_metadata":" | ".join(str(m.get("metadata")) for m in res["messages"]),"send_system_timestamp":res["send_ts"],"system_timestamp":datetime.now().isoformat(timespec="seconds"),"collector_success":res["success"],"collector_note":res["note"]})
    with path.open("a",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=FIELDS,delimiter=";",extrasaction="ignore")
        if not exists:w.writeheader()
        w.writerow(row)

def run_one(page,box,bot,test,known,timeout):
    for m in bot_messages(page,bot):known.add(key(m))
    send=datetime.now(); minute=send.replace(second=0,microsecond=0); start=time.monotonic()
    print("\n"+"="*84); print(test.get("area"),"|",test["test_id"],"|",test["question"]); print("="*84)
    box.click(); box.fill(test["question"]); box.press("Enter"); print(f"Inviato. Timeout={timeout}s")
    deadline=time.monotonic()+timeout; collected={}; first=None
    while time.monotonic()<deadline:
        cs=candidates(page,bot,known,minute)
        if cs:
            first=time.monotonic()
            for m in cs:collected[key(m)]=m
            break
        page.wait_for_timeout(500)
    if not collected:return {"response":"","latency_ms":None,"messages":[],"truncated":False,"success":False,"note":"TIMEOUT_ABORT_RUN","send_ts":send.isoformat(timespec="seconds")}
    lat=int((first-start)*1000); print("Prima risposta:",lat,"ms")
    page.wait_for_timeout(1200)
    for m in candidates(page,bot,known,minute):collected[key(m)]=m
    for m in list(collected.values()):expand(page,m.get("message_id"))
    last=time.monotonic(); prev=set(collected)
    while True:
        page.wait_for_timeout(500); cur={key(m):m for m in candidates(page,bot,known,minute)}
        if set(cur)!=prev:prev=set(cur);last=time.monotonic()
        collected.update(cur)
        if time.monotonic()-last>=6:break
    logical={}
    for m in collected.values():
        ck=(m["metadata"],norm(m["text"])[:220])
        if ck not in logical:logical[ck]=m
        else:
            if m.get("message_id") and not logical[ck].get("message_id"):logical[ck]["message_id"]=m["message_id"]
            if len(m["text"])>len(logical[ck]["text"]):logical[ck]["text"]=m["text"]
    msgs=sorted(logical.values(),key=lambda m:(m.get("message_dt") or minute,m.get("dom_index",0))); resp="\n\n".join(m["text"].strip() for m in msgs); trunc="Leggi di più" in resp
    for m in msgs:known.add(key(m))
    print(resp); return {"response":resp,"latency_ms":lat,"messages":msgs,"truncated":trunc,"success":bool(resp),"note":"OK" if resp else "EMPTY_FINAL_RESPONSE","send_ts":send.isoformat(timespec="seconds")}

def evaluate(raw,run_dir):
    try:
        from evaluate_pecus_autotest_v2 import evaluate_file
        r=evaluate_file(raw,run_dir); print("Valutazione aggiornata:",r["summary"])
    except Exception as e: print("Raccolta salvata; evaluator non completato:",repr(e))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--mode",choices=["smoke","functional","regression","all"],default="smoke")
    ap.add_argument("--suite",default=str(DEFAULT_SUITE))
    ap.add_argument("--bot-name",default=DEFAULT_BOT_NAME)
    ap.add_argument("--timeout",type=int,default=240)
    ap.add_argument("--resume",default=None,help="Cartella results/AUTO_... da riprendere")
    ap.add_argument("--settle-seconds",type=int,default=30,help="Quarantena iniziale in resume")
    a=ap.parse_args()

    if a.resume:
        run_dir=Path(a.resume); raw=run_dir/"raw_results.csv"; snap=run_dir/"suite_snapshot.csv"
        if not raw.exists() or not snap.exists(): raise SystemExit("Resume non valido: mancano raw_results.csv o suite_snapshot.csv")
        suite=load(snap)
        with raw.open("r",encoding="utf-8-sig",newline="") as f: existing=list(csv.DictReader(f,delimiter=";"))
        if not existing: raise SystemExit("Raw vuoto")
        run_id=existing[0]["run_id"]; mode=existing[0]["run_mode"]; tests=select(suite,mode)
        successes={r["test_id"] for r in existing if str(r.get("collector_success","")).lower()=="true"}
        attempts=Counter(r["test_id"] for r in existing)
        pending=[(i+1,t) for i,t in enumerate(tests) if t["test_id"] not in successes]
        print("RESUME",run_id,"mode",mode,"validi",len(successes),"pendenti",len(pending))
    else:
        suite_path=Path(a.suite)
        if not suite_path.exists(): raise SystemExit(f"Suite non trovata: {suite_path}")
        suite=load(suite_path); tests=select(suite,a.mode); mode=a.mode; run_id="AUTO_"+datetime.now().strftime("%Y%m%d_%H%M%S"); run_dir=Path("results")/run_id; run_dir.mkdir(parents=True,exist_ok=False); raw=run_dir/"raw_results.csv"; shutil.copy2(suite_path,run_dir/"suite_snapshot.csv"); successes=set(); attempts=Counter(); pending=[(i+1,t) for i,t in enumerate(tests)]
        print("NUOVO RUN",run_id,"mode",mode,"test",len(tests))

    with sync_playwright() as p:
        ctx=p.chromium.launch_persistent_context(user_data_dir="./whatsapp_profile",headless=False); page=ctx.pages[0]
        if not page.url.startswith("https://web.whatsapp.com"):page.goto("https://web.whatsapp.com")
        page.wait_for_timeout(5000)
        box=page.locator('[contenteditable="true"][role="textbox"][data-tab="10"]'); box.wait_for(state="visible",timeout=30000)
        if a.resume and a.settle_seconds>0:
            print(f"Resume: quarantena {a.settle_seconds}s per assorbire eventuali risposte tardive...")
            page.wait_for_timeout(a.settle_seconds*1000)
        known={key(m) for m in bot_messages(page,a.bot_name)}
        prev_area=None; prev_scen=None
        for seq,test in pending:
            if prev_area and test.get("area")!=prev_area: page.wait_for_timeout(8000)
            if test.get("suite_type")=="regression" and prev_scen and test.get("scenario")!=prev_scen: page.wait_for_timeout(8000)
            attempt=attempts[test["test_id"]]+1
            res=run_one(page,box,a.bot_name,test,known,a.timeout); append(raw,run_id,mode,seq,attempt,test,res); attempts[test["test_id"]]+=1
            print(f"Salvato seq={seq}/{len(tests)} attempt={attempt}")
            if not res["success"]:
                print("STOP protettivo. Per riprendere più tardi:"); print(f'py run_pecus_autotest_v2.py --resume "{run_dir}"')
                break
            prev_area=test.get("area"); prev_scen=test.get("scenario"); page.wait_for_timeout(5000)
        ctx.close()
    evaluate(raw,run_dir); print("Cartella:",run_dir)
if __name__=="__main__":
    from collections import Counter
    main()
