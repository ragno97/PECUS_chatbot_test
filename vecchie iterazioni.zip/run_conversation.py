from playwright.sync_api import sync_playwright
from pathlib import Path
from datetime import datetime
import csv
import time
import re
import uuid


# ============================================================
# CONFIG
# ============================================================

BOT_NAME = "Marica Marches"

TEST_FILE = Path("tests/conversation_tests.csv")
RESULTS_DIR = Path("results")
RESULTS_FILE = RESULTS_DIR / "conversation_results.csv"

TIMEOUT_SECONDS = 90
QUIET_SECONDS = 3

# Pausa tra una domanda e la successiva.
# Non serve per "resettare" il contesto:
# serve solo a evitare sovrapposizioni.
BETWEEN_QUESTIONS_SECONDS = 4

RESULTS_DIR.mkdir(exist_ok=True)

RUN_ID = (
    "RUN_"
    + datetime.now().strftime("%Y%m%d_%H%M%S")
)


# ============================================================
# UTILITY
# ============================================================

def normalize_text(text):
    return re.sub(
        r"\s+",
        " ",
        text
    ).strip()


def fingerprint(message):

    normalized = normalize_text(
        message["text"]
    )

    return (
        message["metadata"],
        normalized[:180]
    )


# ============================================================
# LETTURA MESSAGGI PECUS
# ============================================================

def get_bot_messages(page):

    locator = page.locator(
        f'[data-pre-plain-text*="{BOT_NAME}:"]'
    )

    raw_messages = []

    for i in range(locator.count()):

        element = locator.nth(i)

        try:

            text = (
                element
                .inner_text()
                .strip()
            )

            metadata = element.get_attribute(
                "data-pre-plain-text"
            )

            message_id = None

            ancestor = element.locator(
                "xpath=ancestor::*[@data-id][1]"
            )

            if ancestor.count() > 0:

                message_id = (
                    ancestor
                    .get_attribute("data-id")
                )

            if text:

                raw_messages.append({
                    "message_id": message_id,
                    "metadata": metadata,
                    "text": text
                })

        except Exception:
            pass

    # Deduplicazione
    deduped = {}

    for message in raw_messages:

        key = fingerprint(message)

        if key not in deduped:

            deduped[key] = message

        else:

            existing = deduped[key]

            if (
                message["message_id"]
                and not existing["message_id"]
            ):

                existing["message_id"] = (
                    message["message_id"]
                )

            if (
                len(message["text"])
                > len(existing["text"])
            ):

                existing["text"] = (
                    message["text"]
                )

    return list(
        deduped.values()
    )


# ============================================================
# ESPANSIONE LEGGI DI PIÙ
# ============================================================

def expand_latest_message(page):

    try:

        more = page.get_by_text(
            "Leggi di più",
            exact=True
        )

        if more.count() > 0:

            more.last.click(
                timeout=3000
            )

            page.wait_for_timeout(700)

            return True

    except Exception:
        pass

    return False


# ============================================================
# CARICAMENTO TEST
# ============================================================

def load_tests():

    tests = []

    with open(
        TEST_FILE,
        "r",
        encoding="utf-8-sig",
        newline=""
    ) as f:

        reader = csv.DictReader(
            f,
            delimiter=";"
        )

        for row in reader:

            row = {
                str(k).strip(): (
                    str(v).strip()
                    if v is not None
                    else ""
                )
                for k, v in row.items()
            }

            tests.append(row)

    return tests


# ============================================================
# SALVATAGGIO RISULTATO
# ============================================================

def save_result(
    test,
    response,
    latency_ms,
    messages,
    truncated
):

    file_exists = (
        RESULTS_FILE.exists()
    )

    with open(
        RESULTS_FILE,
        "a",
        encoding="utf-8-sig",
        newline=""
    ) as f:

        writer = csv.writer(
            f,
            delimiter=";"
        )

        if not file_exists:

            writer.writerow([
                "run_id",
                "test_id",
                "turn",
                "test_family",
                "intent",
                "question",
                "animal_explicit",
                "expected_animal",
                "expected_scope",
                "response",
                "latency_ms",
                "message_count",
                "response_truncated",
                "message_ids",
                "whatsapp_metadata",
                "system_timestamp"
            ])

        writer.writerow([
            RUN_ID,
            test["test_id"],
            test["turn"],
            test["test_family"],
            test["intent"],
            test["question"],
            test["animal_explicit"],
            test["expected_animal"],
            test["expected_scope"],
            response,
            latency_ms,
            len(messages),
            truncated,
            " | ".join(
                str(m["message_id"])
                for m in messages
            ),
            " | ".join(
                str(m["metadata"])
                for m in messages
            ),
            datetime.now().isoformat(
                timespec="seconds"
            )
        ])


# ============================================================
# INVIO + RACCOLTA RISPOSTA
# ============================================================

def run_single_test(
    page,
    message_box,
    test
):

    question = test["question"]

    # Snapshot prima dell'invio
    old_messages = get_bot_messages(
        page
    )

    old_fingerprints = {
        fingerprint(m)
        for m in old_messages
    }

    print()
    print("=" * 70)

    print(
        f'TURN {test["turn"]} '
        f'- {test["test_id"]}'
    )

    print(
        "Famiglia:",
        test["test_family"]
    )

    print(
        "Intent:",
        test["intent"]
    )

    print(
        "Domanda:",
        question
    )

    print("=" * 70)

    # Invio
    start_time = time.monotonic()

    message_box.click()

    message_box.fill(
        question
    )

    message_box.press(
        "Enter"
    )

    print(
        "Messaggio inviato."
    )

    # Attesa risposta
    deadline = (
        time.monotonic()
        + TIMEOUT_SECONDS
    )

    first_response_time = None

    new_messages = []

    while (
        time.monotonic()
        < deadline
    ):

        current = get_bot_messages(
            page
        )

        current_new = [
            m
            for m in current
            if fingerprint(m)
            not in old_fingerprints
        ]

        if current_new:

            first_response_time = (
                time.monotonic()
            )

            new_messages = (
                current_new
            )

            break

        page.wait_for_timeout(
            500
        )

    # Timeout
    if not new_messages:

        print(
            "TIMEOUT: nessuna "
            "risposta rilevata."
        )

        return {
            "response": "",
            "latency_ms": None,
            "messages": [],
            "truncated": False,
            "success": False
        }

    latency_ms = int(
        (
            first_response_time
            - start_time
        )
        * 1000
    )

    print(
        "Prima risposta dopo:",
        latency_ms,
        "ms"
    )

    # Espandi
    expand_latest_message(
        page
    )

    # Attesa stabilizzazione
    stable_since = (
        time.monotonic()
    )

    previous_fps = None

    while True:

        page.wait_for_timeout(
            500
        )

        current = get_bot_messages(
            page
        )

        current_new = [
            m
            for m in current
            if fingerprint(m)
            not in old_fingerprints
        ]

        fps = {
            fingerprint(m)
            for m in current_new
        }

        if fps != previous_fps:

            previous_fps = fps

            stable_since = (
                time.monotonic()
            )

        if (
            time.monotonic()
            - stable_since
            >= QUIET_SECONDS
        ):

            new_messages = (
                current_new
            )

            break

    # Deduplicazione finale
    final_messages = {}

    for message in new_messages:

        key = fingerprint(
            message
        )

        if key not in final_messages:

            final_messages[key] = (
                message
            )

        else:

            existing = (
                final_messages[key]
            )

            if (
                message["message_id"]
                and not
                existing["message_id"]
            ):

                existing[
                    "message_id"
                ] = message[
                    "message_id"
                ]

            if (
                len(message["text"])
                >
                len(existing["text"])
            ):

                existing["text"] = (
                    message["text"]
                )

    final_messages = list(
        final_messages.values()
    )

    response = "\n\n".join(
        m["text"].strip()
        for m in final_messages
    )

    truncated = (
        "Leggi di più"
        in response
    )

    print()
    print("--- RISPOSTA PECUS ---")
    print(response)
    print("-----------------------")

    print(
        "Messaggi:",
        len(final_messages)
    )

    print(
        "Troncata:",
        truncated
    )

    return {
        "response": response,
        "latency_ms": latency_ms,
        "messages": final_messages,
        "truncated": truncated,
        "success": True
    }


# ============================================================
# MAIN
# ============================================================

tests = load_tests()

print(
    "Test caricati:",
    len(tests)
)

print(
    "Run ID:",
    RUN_ID
)


with sync_playwright() as p:

    context = (
        p.chromium
        .launch_persistent_context(
            user_data_dir=(
                "./whatsapp_profile"
            ),
            headless=False
        )
    )

    page = context.pages[0]

    if not page.url.startswith(
        "https://web.whatsapp.com"
    ):

        page.goto(
            "https://web.whatsapp.com"
        )

    print(
        "\nWhatsApp avviato"
    )

    page.wait_for_timeout(
        5000
    )

    message_box = page.locator(
        '[contenteditable="true"]'
        '[role="textbox"]'
        '[data-tab="10"]'
    )

    message_box.wait_for(
        state="visible",
        timeout=30000
    )

    print(
        "Campo messaggio trovato"
    )

    # ========================================================
    # LOOP CONVERSAZIONALE
    # ========================================================

    for index, test in enumerate(
        tests,
        start=1
    ):

        result = run_single_test(
            page,
            message_box,
            test
        )

        save_result(
            test=test,
            response=result[
                "response"
            ],
            latency_ms=result[
                "latency_ms"
            ],
            messages=result[
                "messages"
            ],
            truncated=result[
                "truncated"
            ]
        )

        print(
            f"\nSalvato test "
            f"{index}/{len(tests)}"
        )

        # Pausa tra turni
        if index < len(tests):

            print(
                "Pausa prima del "
                "turno successivo..."
            )

            page.wait_for_timeout(
                BETWEEN_QUESTIONS_SECONDS
                * 1000
            )

    print()
    print("=" * 70)
    print(
        "RUN COMPLETATO"
    )
    print("=" * 70)

    print(
        "Run ID:",
        RUN_ID
    )

    print(
        "Risultati:",
        RESULTS_FILE
    )

    input(
        "\nPremi INVIO per chiudere..."
    )

    context.close()