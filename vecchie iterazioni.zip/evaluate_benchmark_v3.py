from __future__ import annotations

import argparse
import csv
import re
from collections import Counter, defaultdict
from pathlib import Path


RISK_TERMS = r"rischio|probabilit|mastite|stress da cal|heat stress|chetosi"
CAUSE_TERMS = r"deriv|causa|dovut|perch[eé]|stress|temperatur|umidit|mastite"
SIGNAL_TERMS = r"segnal|scostamento|conducibilit|THI|ore di caldo|calo produzione|residuo"
TREND_TERMS = r"trend|ultimi giorni|giorni|andamento|aument|dimin|stabile|media"


def b(v):
    return str(v).strip().lower() in {"true","1","yes","si","sì"}


def animal(v):
    v = str(v or "").strip()
    if not v or v.lower() == "nan":
        return ""
    try:
        return str(int(float(v.replace(",","."))))
    except ValueError:
        return v


def extract_animals(text):
    ids = set()
    for p in (
        r"#\s*(\d{3,6})\b",
        r"\b(?:bufala|bovina|vacca|animale)\s+#?(\d{3,6})\b",
        r"^\s*#?(\d{3,6})\b",
    ):
        for m in re.finditer(p, str(text), re.I | re.M):
            n = int(m.group(1))
            if 100 <= n <= 999999:
                ids.add(str(n))
    return sorted(ids, key=int)


def detected_scope(text):
    low = str(text).lower()
    ids = extract_animals(text)
    if len(ids) >= 2:
        return "herd"
    if len(ids) == 1:
        return "animal"
    if "mandria" in low or "produzione totale" in low or "numero di bufale" in low:
        return "herd"
    return "unclear"


def collector_status(row):
    flags = []
    response = str(row.get("response","") or "").strip()
    if not b(row.get("collector_success","False")):
        flags.append("COLLECTOR_FAILURE")
    try:
        count = int(float(row.get("message_count",0) or 0))
    except Exception:
        count = 0
    if not response or response.lower() == "nan" or count == 0:
        flags.append("EMPTY_RESPONSE")
    if b(row.get("response_truncated","False")):
        flags.append("TRUNCATED_RESPONSE")
    if count > 3:
        flags.append("POSSIBLE_DOM_CONTAMINATION")
    return ("PASS" if not flags else "FAIL"), flags


def scope_and_animal(row, response):
    expected_scope = row["expected_scope"]
    expected_animal = animal(row.get("expected_animal",""))
    scope = detected_scope(response)
    ids = extract_animals(response)
    flags = []

    if expected_scope == "neutral":
        return "N/A","N/A",flags

    if expected_scope == "herd":
        if scope == "herd":
            return "PASS","N/A",flags
        flags.append("WRONG_SCOPE")
        return "FAIL","N/A",flags

    if expected_animal and expected_animal in ids and len(ids) == 1:
        return "PASS","PASS_EXPLICIT",flags

    if expected_animal and expected_animal in ids and len(ids) > 1:
        flags.append("SCOPE_DRIFT")
        return "FAIL","PASS_MIXED_WITH_HERD",flags

    if ids and expected_animal not in ids:
        flags.append("WRONG_ANIMAL")
        return ("PASS" if scope == "animal" else "FAIL"),"FAIL",flags

    flags.append("ANIMAL_UNRESOLVED_IN_TEXT")
    if scope == "herd":
        flags.append("SCOPE_DRIFT")
        return "FAIL","REVIEW",flags

    return "REVIEW","REVIEW",flags


def intent_status(intent, response, scope):
    t = str(response)
    low = t.lower()

    if intent == "acknowledgement":
        return "N/A"

    if intent == "animal_profile":
        categories = 0
        if re.search(r"\bDIM\b|\bL\d\b|\bP\d\b|lattazion", t, re.I):
            categories += 1
        if re.search(r"produ|\bkg\b", t, re.I):
            categories += 1
        if re.search(RISK_TERMS, t, re.I):
            categories += 1
        return "PASS" if categories >= 2 else "REVIEW"

    if intent == "daily_milk_yield":
        return "PASS" if re.search(r"\b\d+(?:[.,]\d+)?\s*kg\b", t, re.I) else "FAIL"

    if intent == "previous_milk_yield":
        if re.search(r"ieri|29 agosto|29/08|giorno precedente", t, re.I):
            return "PASS"
        if re.search(r"oggi|30 agosto|30/08", t, re.I):
            return "FAIL"
        return "REVIEW"

    if intent == "risk":
        return "PASS" if re.search(RISK_TERMS, t, re.I) else "FAIL"

    if intent == "risk_reason":
        return "PASS" if re.search(CAUSE_TERMS, t, re.I) else "REVIEW"

    if intent == "risk_signals":
        return "PASS" if re.search(SIGNAL_TERMS, t, re.I) else "REVIEW"

    if intent == "milk_loss":
        return "PASS" if re.search(r"perdit.*\bkg\b|\bkg\b.*perdit", t, re.I | re.S) else "FAIL"

    if intent == "production_vs_expected":
        return "PASS" if re.search(r"attes|baseline|scostamento|residuo|previst", t, re.I) else "FAIL"

    if intent == "production_trend":
        return "PASS" if re.search(TREND_TERMS, t, re.I) else "REVIEW"

    if intent == "herd_risk":
        return "PASS" if scope == "herd" and re.search(RISK_TERMS, t, re.I) else "FAIL"

    if intent == "herd_similar":
        return "PASS" if scope == "herd" and re.search(r"perdit|scostamento|\bkg\b", t, re.I) else "FAIL"

    return "REVIEW"


def extract_production(text):
    t = str(text)
    def num(v):
        return float(v.replace("−","-").replace("–","-").replace(",","."))
    m = re.search(
        r"#?3118:\s*(?P<a>\d+(?:[.,]\d+)?)\s*kg"
        r".{0,100}?attes[ioa]\s*(?P<e>\d+(?:[.,]\d+)?)\s*kg"
        r".{0,100}?(?P<p>[−–-]?\d+(?:[.,]\d+)?)\s*%",
        t, re.I | re.S
    )
    if m:
        return num(m.group("a")),num(m.group("e")),num(m.group("p"))
    m = re.search(r"(?:bufala\s+)?#?3118.{0,120}?(\d+(?:[.,]\d+)?)\s*kg", t, re.I | re.S)
    if m:
        return num(m.group(1)),None,None
    return None,None,None


def evaluate(rows):
    out = []
    decay_failed = False

    for row in rows:
        response = str(row.get("response","") or "")
        coll_status, coll_flags = collector_status(row)
        scope = detected_scope(response)

        if coll_status == "FAIL":
            scope_status = "N/A"
            animal_status = "N/A"
            intent = "N/A"
            flags = coll_flags[:]
            overall = "INVALID_COLLECTOR"
        else:
            scope_status, animal_status, flags = scope_and_animal(row,response)
            intent = intent_status(row["intent"],response,scope)

            hard = scope_status == "FAIL" or animal_status == "FAIL" or intent == "FAIL"
            review = scope_status == "REVIEW" or animal_status == "REVIEW" or intent == "REVIEW"
            overall = "FAIL" if hard else ("REVIEW" if review else "PASS")

        scored = True
        post_failure = False

        if row["scenario"] == "A_CONTEXT_DECAY" and row["probe_type"] == "context_probe":
            if decay_failed:
                scored = False
                post_failure = True
            elif overall != "PASS":
                decay_failed = True

        actual,expected,pct = extract_production(response)

        r = dict(row)
        r.update({
            "collector_status":coll_status,
            "detected_scope":scope,
            "detected_animals":",".join(extract_animals(response)),
            "scope_correct":scope_status,
            "animal_correct":animal_status,
            "intent_correct":intent,
            "overall_status":overall,
            "error_flags":"|".join(flags),
            "scored_for_primary_metric":scored,
            "post_failure_unscored":post_failure,
            "production_actual_kg":"" if actual is None else actual,
            "production_expected_kg":"" if expected is None else expected,
            "production_pct":"" if pct is None else pct,
        })
        out.append(r)

    return out


def pct(n,d):
    return round(100*n/d,1) if d else ""


def summaries(rows):
    scenario_rows = []
    by = defaultdict(list)
    for r in rows:
        by[r["scenario"]].append(r)

    for scenario, rs in by.items():
        valid = [r for r in rs if r["collector_status"] == "PASS"]
        primary = [
            r for r in valid
            if str(r["scored_for_primary_metric"]).lower() != "false"
            and r["expected_scope"] != "neutral"
        ]
        passed = sum(r["overall_status"] == "PASS" for r in primary)
        scenario_rows.append({
            "scenario":scenario,
            "tests_total":len(rs),
            "collector_valid":len(valid),
            "primary_scored":len(primary),
            "primary_pass":passed,
            "primary_success_pct":pct(passed,len(primary)),
        })

    depth = 0
    a = sorted([r for r in rows if r["scenario"]=="A_CONTEXT_DECAY"], key=lambda r:int(r["scenario_turn"]))
    for r in a:
        if r["probe_type"] != "context_probe":
            continue
        if r["overall_status"] == "PASS":
            depth += 1
        else:
            break

    recovery = [r for r in rows if r["probe_type"]=="recovery_probe" and r["collector_status"]=="PASS"]
    entity = [r for r in rows if r["probe_type"] in {"entity_probe","previous_entity_probe"} and r["collector_status"]=="PASS"]
    noise = [r for r in rows if r["probe_type"]=="noise_recovery_probe" and r["collector_status"]=="PASS"]
    para = [r for r in rows if r["probe_type"]=="paraphrase_probe" and r["collector_status"]=="PASS"]

    headline = {
        "context_retention_depth_strict":depth,
        "scope_recovery_pass":f"{sum(r['overall_status']=='PASS' for r in recovery)}/{len(recovery)}",
        "scope_recovery_pct":pct(sum(r["overall_status"]=="PASS" for r in recovery),len(recovery)),
        "entity_probe_pass":f"{sum(r['overall_status']=='PASS' for r in entity)}/{len(entity)}",
        "entity_probe_pct":pct(sum(r["overall_status"]=="PASS" for r in entity),len(entity)),
        "noise_recovery_pass":f"{sum(r['overall_status']=='PASS' for r in noise)}/{len(noise)}",
        "noise_recovery_pct":pct(sum(r["overall_status"]=="PASS" for r in noise),len(noise)),
        "paraphrase_pass":f"{sum(r['overall_status']=='PASS' for r in para)}/{len(para)}",
        "paraphrase_pass_pct":pct(sum(r["overall_status"]=="PASS" for r in para),len(para)),
    }

    actuals = [float(r["production_actual_kg"]) for r in para if str(r["production_actual_kg"]) != ""]
    if actuals:
        counts = Counter(round(x,2) for x in actuals)
        modal, n = counts.most_common(1)[0]
        headline["paraphrase_modal_actual_kg"] = modal
        headline["paraphrase_value_consistency_pct"] = pct(n,len(actuals))
    else:
        headline["paraphrase_modal_actual_kg"] = ""
        headline["paraphrase_value_consistency_pct"] = ""

    return scenario_rows,headline


def write_csv(path,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys()),delimiter=";")
        w.writeheader(); w.writerows(rows)


def main():
    p=argparse.ArgumentParser()
    p.add_argument("input",nargs="?",default="results/benchmark_v3_results.csv")
    p.add_argument("--output",default="results/benchmark_v3_evaluated.csv")
    p.add_argument("--scenario-output",default="results/benchmark_v3_scenarios.csv")
    p.add_argument("--summary",default="results/benchmark_v3_summary.txt")
    args=p.parse_args()

    with Path(args.input).open("r",encoding="utf-8-sig",newline="") as f:
        rows=list(csv.DictReader(f,delimiter=";"))

    if not rows:
        raise SystemExit("Nessun risultato.")

    ev=evaluate(rows)
    sc,head=summaries(ev)
    write_csv(Path(args.output),ev)
    write_csv(Path(args.scenario_output),sc)

    lines=["PECUS CHAIN — Benchmark V3 Summary","="*48,f"Run ID: {ev[0]['run_id']}",f"Test raccolti: {len(ev)}","",
           "HEADLINE METRICS","-"*48]
    for k,v in head.items():
        lines.append(f"{k}: {v}")
    lines += ["","SCENARIOS","-"*48]
    for s in sc:
        lines.append(
            f"{s['scenario']}: valid={s['collector_valid']}/{s['tests_total']}, "
            f"primary={s['primary_pass']}/{s['primary_scored']} ({s['primary_success_pct']}%)"
        )
    lines += ["","NON-PASS / INVALID","-"*48]
    for r in ev:
        if r["overall_status"]!="PASS":
            lines.append(
                f"{r['test_id']} | {r['overall_status']} | {r['error_flags']} | "
                f"scope={r['detected_scope']} | animals={r['detected_animals']} | Q={r['question']}"
            )
    Path(args.summary).write_text("\n".join(lines)+"\n",encoding="utf-8")

    c=Counter(r["overall_status"] for r in ev)
    print("Valutati:",len(ev))
    print("PASS=",c["PASS"],"REVIEW=",c["REVIEW"],"FAIL=",c["FAIL"],"INVALID_COLLECTOR=",c["INVALID_COLLECTOR"])
    print("Summary:",args.summary)


if __name__=="__main__":
    main()
