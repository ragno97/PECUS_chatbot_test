from playwright.sync_api import sync_playwright
from pathlib import Path
from datetime import datetime
import csv
import time
import re


# ============================================================
# CONFIG
# ============================================================

BOT_NAME = "Marica Marches"

QUESTION = "quanto produce oggi la 3118?"

RESULTS_DIR = Path("results")
RESULTS_FILE = RESULTS_DIR / "single_test_v2.csv"

TIMEOUT_SECONDS = 90
QUIET_SECONDS = 3

RESULTS_DIR.mkdir(exist_ok=True)


# ============================================================
# UTILITY
# ============================================================

def normalize_text(text):
    return re.sub(r"\s+", " ", text).strip()


def fingerprint(message):
    """
    Identifica logicamente un messaggio anche se WhatsApp
    assegna il data-id qualche istante dopo.

    Metadata + inizio del testo restano generalmente stabili
    anche dopo l'espansione di 'Leggi di più'.
    """

    normalized = normalize_text(message["text"])

    return (
        message["metadata"],
        normalized[:180]
    )


# ============================================================
# LETTURA MESSAGGI BOT
# ============================================================

def get_bot_messages(page):

    locator = page.locator(
        f'[data-pre-plain-text*="{BOT_NAME}:"]'
    )

    raw_messages = []

    for i in range(locator.count()):

        element = locator.nth(i)

        try:

            text = element.inner_text().strip()

            metadata = element.get_attribute(
                "data-pre-plain-text"
            )

            message_id = None

            ancestor = element.locator(
                "xpath=ancestor::*[@data-id][1]"
            )

            if ancestor.count() > 0:

                message_id = ancestor.get_attribute(
                    "data-id"
                )

            if text:

                raw_messages.append({
                    "message_id": message_id,
                    "metadata": metadata,
                    "text": text
                })

        except Exception:
            pass

    # ========================================================
    # DEDUPLICAZIONE
    # ========================================================

    deduped = {}

    for message in raw_messages:

        key = fingerprint(message)

        if key not in deduped:

            deduped[key] = message

        else:

            existing = deduped[key]

            # Preferisce versione con ID
            if (
                message["message_id"]
                and not existing["message_id"]
            ):
                existing["message_id"] = (
                    message["message_id"]
                )

            # Preferisce testo più lungo
            if (
                len(message["text"])
                > len(existing["text"])
            ):
                existing["text"] = (
                    message["text"]
                )

    return list(deduped.values())


# ============================================================
# ESPANSIONE "LEGGI DI PIÙ"
# ============================================================

def expand_latest_message(page):

    try:

        more = page.get_by_text(
            "Leggi di più",
            exact=True
        )

        if more.count() > 0:

            print(
                "Messaggio lungo rilevato: "
                "espando 'Leggi di più'..."
            )

            more.last.click(
                timeout=3000
            )

            page.wait_for_timeout(700)

            return True

    except Exception:
        pass

    return False


# ============================================================
# PLAYWRIGHT
# ============================================================

with sync_playwright() as p:

    context = p.chromium.launch_persistent_context(
        user_data_dir="./whatsapp_profile",
        headless=False
    )

    page = context.pages[0]

    if not page.url.startswith(
        "https://web.whatsapp.com"
    ):
        page.goto(
            "https://web.whatsapp.com"
        )

    print("WhatsApp avviato")

    page.wait_for_timeout(5000)

    # ========================================================
    # COMPOSER
    # ========================================================

    message_box = page.locator(
        '[contenteditable="true"]'
        '[role="textbox"]'
        '[data-tab="10"]'
    )

    message_box.wait_for(
        state="visible",
        timeout=30000
    )

    print("Campo messaggio trovato")

    # ========================================================
    # SNAPSHOT PRIMA DELL'INVIO
    # ========================================================

    page.wait_for_timeout(1500)

    old_messages = get_bot_messages(page)

    old_fingerprints = {
        fingerprint(m)
        for m in old_messages
    }

    print(
        "\nMessaggi PECUS visibili prima:",
        len(old_messages)
    )

    # ========================================================
    # INVIO
    # ========================================================

    print("\n--------------------------------")
    print("Domanda:", QUESTION)
    print("--------------------------------")

    start_time = time.monotonic()

    message_box.click()
    message_box.fill(QUESTION)
    message_box.press("Enter")

    print("Messaggio inviato")
    print("Attendo nuova risposta PECUS...")

    # ========================================================
    # ATTESA NUOVO MESSAGGIO
    # ========================================================

    deadline = (
        time.monotonic()
        + TIMEOUT_SECONDS
    )

    first_response_time = None
    new_messages = []

    while time.monotonic() < deadline:

        current = get_bot_messages(page)

        current_new = [
            m for m in current
            if fingerprint(m)
            not in old_fingerprints
        ]

        if current_new:

            first_response_time = (
                time.monotonic()
            )

            new_messages = current_new

            break

        page.wait_for_timeout(500)

    if not new_messages:

        print(
            "\nERRORE: nessuna risposta "
            f"entro {TIMEOUT_SECONDS} secondi."
        )

        input(
            "\nPremi INVIO per chiudere..."
        )

        context.close()

        raise SystemExit

    latency_ms = int(
        (
            first_response_time
            - start_time
        )
        * 1000
    )

    print(
        "\nPrima risposta rilevata dopo",
        latency_ms,
        "ms"
    )

    # ========================================================
    # ESPANSIONE TESTO
    # ========================================================

    expand_latest_message(page)

    # ========================================================
    # ATTENDE STABILIZZAZIONE RISPOSTA
    # ========================================================

    stable_since = time.monotonic()

    previous_fps = None

    while True:

        page.wait_for_timeout(500)

        current = get_bot_messages(page)

        current_new = [
            m for m in current
            if fingerprint(m)
            not in old_fingerprints
        ]

        fps = {
            fingerprint(m)
            for m in current_new
        }

        if fps != previous_fps:

            previous_fps = fps
            stable_since = time.monotonic()

        if (
            time.monotonic()
            - stable_since
            >= QUIET_SECONDS
        ):
            new_messages = current_new
            break

    # ========================================================
    # DEDUPLICAZIONE FINALE
    # ========================================================

    final_messages = {}

    for message in new_messages:

        key = fingerprint(message)

        if key not in final_messages:

            final_messages[key] = message

        else:

            existing = final_messages[key]

            if (
                message["message_id"]
                and not existing["message_id"]
            ):
                existing["message_id"] = (
                    message["message_id"]
                )

            if (
                len(message["text"])
                > len(existing["text"])
            ):
                existing["text"] = (
                    message["text"]
                )

    new_messages = list(
        final_messages.values()
    )

    # ========================================================
    # RISPOSTA COMPLETA
    # ========================================================

    response = "\n\n".join(
        m["text"].strip()
        for m in new_messages
    )

    truncated = (
        "Leggi di più"
        in response
    )

    # ========================================================
    # OUTPUT
    # ========================================================

    print("\n" + "=" * 70)
    print("RISPOSTA PECUS")
    print("=" * 70)

    print(response)

    print("=" * 70)

    print(
        "Messaggi logici:",
        len(new_messages)
    )

    print(
        "Latenza:",
        latency_ms,
        "ms"
    )

    print(
        "Risposta troncata:",
        truncated
    )

    for i, message in enumerate(
        new_messages,
        start=1
    ):

        print(
            f"\nMessaggio {i}"
        )

        print(
            "ID:",
            message["message_id"]
        )

        print(
            "Metadata:",
            message["metadata"]
        )

    # ========================================================
    # CSV
    # ========================================================

    file_exists = RESULTS_FILE.exists()

    with open(
        RESULTS_FILE,
        "a",
        newline="",
        encoding="utf-8-sig"
    ) as f:

        writer = csv.writer(
            f,
            delimiter=";"
        )

        if not file_exists:

            writer.writerow([
                "timestamp",
                "question",
                "response",
                "latency_ms",
                "message_count",
                "response_truncated",
                "whatsapp_metadata",
                "message_ids"
            ])

        writer.writerow([
            datetime.now().isoformat(
                timespec="seconds"
            ),
            QUESTION,
            response,
            latency_ms,
            len(new_messages),
            truncated,
            " | ".join(
                str(m["metadata"])
                for m in new_messages
            ),
            " | ".join(
                str(m["message_id"])
                for m in new_messages
            )
        ])

    print(
        "\nRisultato salvato in:",
        RESULTS_FILE
    )

    input(
        "\nPremi INVIO per chiudere..."
    )

    context.close()