from __future__ import annotations

import argparse
import csv
import re
import statistics
from collections import Counter, defaultdict
from pathlib import Path


HERD_TERMS = (
    "altre bufale",
    "bufale segnalate",
    "le bufale",
    "mandria",
    "altri animali",
    "animali segnalati",
    "altre bovine",
    "altre vacche",
)

INTENT_PATTERNS = {
    "animal_profile": (r"bufala|bovina|vacca|animale",),
    "daily_milk_yield": (r"produ|latte", r"\bkg\b|produzione"),
    "previous_milk_yield": (r"ieri|giorno precedente|precedente", r"produ|\bkg\b|latte"),
    "risk": (r"rischio|stress|probabilit",),
    "risk_reason": (r"stress|calore|termic|THI|temperatur|umidit|causa|deriv",),
    "risk_signals": (r"segnal|indic|calo|ore di caldo|THI|temperatur|umidit",),
    "milk_loss": (r"perdit|pers|mancan", r"\bkg\b|latte"),
    "production_vs_expected": (r"attes|previst|baseline|curva|scostamento|residuo",),
    "herd_risk": (r"bufale|animali|mandria", r"rischio|stress|segnalat"),
    "herd_similar": (r"bufale|animali|mandria", r"simil|stessa|perdit|scostamento"),
    "acknowledgement": (),
}


def normalize_bool(value: str) -> bool:
    return str(value).strip().lower() in {"true", "1", "yes", "y", "si", "sì"}


def normalize_animal(value: str) -> str:
    value = str(value or "").strip()

    if not value:
        return ""

    try:
        return str(int(float(value.replace(",", "."))))
    except ValueError:
        return value


def extract_animals(text: str) -> list[str]:
    ids = set()

    for pattern in (
        r"#\s*(\d{3,6})\b",
        r"\b(?:bufala|bovina|vacca|animale)\s+#?(\d{3,6})\b",
        r"^\s*#?(\d{3,6})\b",
    ):
        for match in re.finditer(pattern, text, flags=re.IGNORECASE | re.MULTILINE):
            value = int(match.group(1))

            if 100 <= value <= 999999:
                ids.add(str(value))

    return sorted(ids, key=int)


def detect_scope(text: str) -> str:
    low = text.lower()
    animals = extract_animals(text)

    if len(animals) >= 2 or any(term in low for term in HERD_TERMS):
        return "herd"

    if len(animals) == 1:
        return "animal"

    if re.search(
        r"\b(questa bufala|la bufala|questa bovina|la bovina|la produzione|"
        r"produzione:|il suo rischio|i suoi dati)\b",
        low,
    ):
        return "animal"

    return "unclear"


def intent_status(intent: str, response: str) -> str:
    patterns = INTENT_PATTERNS.get(intent)

    if patterns is None:
        return "REVIEW"

    if intent == "acknowledgement":
        return "N/A"

    return (
        "PASS"
        if all(re.search(p, response, flags=re.IGNORECASE) for p in patterns)
        else "FAIL"
    )


def context_distance_by_scenario(rows: list[dict]) -> dict[tuple[str, str], str]:
    distances = {}

    by_key = defaultdict(list)

    for row in rows:
        by_key[(row["run_id"], row["scenario"])].append(row)

    for (run_id, scenario), scenario_rows in by_key.items():
        scenario_rows.sort(key=lambda r: int(r["scenario_turn"]))

        last_explicit_turn = None
        active_animal = ""

        for row in scenario_rows:
            turn = int(row["scenario_turn"])
            expected_scope = row["expected_scope"]
            expected_animal = normalize_animal(row["expected_animal"])

            if normalize_bool(row["animal_explicit"]) and expected_animal:
                active_animal = expected_animal
                last_explicit_turn = turn
                distances[(run_id, row["test_id"])] = "0"
                continue

            if expected_scope == "animal" and expected_animal and last_explicit_turn is not None:
                if expected_animal == active_animal:
                    distances[(run_id, row["test_id"])] = str(turn - last_explicit_turn)
                else:
                    distances[(run_id, row["test_id"])] = ""
            else:
                distances[(run_id, row["test_id"])] = ""

    return distances


def evaluate(rows: list[dict]) -> list[dict]:
    distances = context_distance_by_scenario(rows)
    out = []

    for row in rows:
        response = row.get("response", "") or ""
        expected_scope = row["expected_scope"]
        expected_animal = normalize_animal(row["expected_animal"])
        probe_type = row["probe_type"]

        detected_animals = extract_animals(response)
        detected_scope = detect_scope(response)

        if expected_scope == "neutral":
            scope_correct = "N/A"
            animal_correct = "N/A"
            context_correct = "N/A"
        else:
            scope_correct = "PASS" if detected_scope == expected_scope else "FAIL"

            if expected_scope == "herd":
                animal_correct = "N/A"
            elif expected_animal in detected_animals:
                animal_correct = "PASS_EXPLICIT"
            elif detected_animals and expected_animal not in detected_animals:
                animal_correct = "FAIL"
            elif detected_scope == "animal":
                animal_correct = "PASS_IMPLICIT"
            else:
                animal_correct = "REVIEW"

            context_correct = (
                "PASS"
                if scope_correct == "PASS"
                and animal_correct in {"PASS_EXPLICIT", "PASS_IMPLICIT", "N/A"}
                else "FAIL"
            )

        i_status = intent_status(row["intent"], response)

        errors = []

        if expected_scope != "neutral" and scope_correct == "FAIL":
            if expected_scope == "animal" and detected_scope == "herd":
                errors.append("CONTEXT_SCOPE_DRIFT")
            else:
                errors.append("WRONG_SCOPE")

        if animal_correct == "FAIL":
            errors.append("WRONG_ANIMAL")

        if i_status == "FAIL":
            errors.append("WRONG_INTENT")

        if not normalize_bool(row.get("collector_success", "True")):
            errors.append("COLLECTOR_FAILURE")

        if normalize_bool(row.get("response_truncated", "False")):
            errors.append("TRUNCATED_RESPONSE")

        if expected_scope == "neutral":
            overall = "PASS"
        elif any(
            e in {
                "CONTEXT_SCOPE_DRIFT",
                "WRONG_SCOPE",
                "WRONG_ANIMAL",
                "WRONG_INTENT",
                "COLLECTOR_FAILURE",
            }
            for e in errors
        ):
            overall = "FAIL"
        elif animal_correct == "REVIEW" or i_status == "REVIEW":
            overall = "REVIEW"
        else:
            overall = "PASS"

        record = dict(row)
        record.update(
            {
                "context_distance": distances.get((row["run_id"], row["test_id"]), ""),
                "detected_animals": ",".join(detected_animals),
                "detected_scope": detected_scope,
                "animal_correct": animal_correct,
                "scope_correct": scope_correct,
                "intent_correct": i_status,
                "context_correct": context_correct,
                "error_type": "|".join(errors),
                "overall_status": overall,
            }
        )

        out.append(record)

    return out


def scenario_metrics(evaluated: list[dict]) -> list[dict]:
    grouped = defaultdict(list)

    for row in evaluated:
        grouped[row["scenario"]].append(row)

    metrics = []

    for scenario, rows in grouped.items():
        scored = [r for r in rows if r["expected_scope"] != "neutral"]
        context_scored = [r for r in scored if r["context_correct"] != "N/A"]

        context_pass = sum(r["context_correct"] == "PASS" for r in context_scored)
        scope_pass = sum(r["scope_correct"] == "PASS" for r in scored)

        animal_rows = [r for r in scored if r["expected_scope"] == "animal"]
        animal_pass = sum(
            r["animal_correct"] in {"PASS_EXPLICIT", "PASS_IMPLICIT"}
            for r in animal_rows
        )

        probe_rows = [
            r
            for r in rows
            if r["probe_type"]
            in {
                "context_probe",
                "recovery_probe",
                "entity_probe",
                "previous_entity_probe",
                "noise_recovery_probe",
            }
        ]

        probe_pass = sum(r["context_correct"] == "PASS" for r in probe_rows)

        metrics.append(
            {
                "scenario": scenario,
                "tests": len(rows),
                "scored_tests": len(scored),
                "context_accuracy_pct": round(
                    100 * context_pass / len(context_scored), 1
                )
                if context_scored
                else "",
                "scope_accuracy_pct": round(
                    100 * scope_pass / len(scored), 1
                )
                if scored
                else "",
                "animal_resolution_pct": round(
                    100 * animal_pass / len(animal_rows), 1
                )
                if animal_rows
                else "",
                "probe_success_pct": round(
                    100 * probe_pass / len(probe_rows), 1
                )
                if probe_rows
                else "",
            }
        )

    return metrics


def observed_retention_depth(evaluated: list[dict]) -> dict[str, str]:
    result = {}

    for scenario in sorted({r["scenario"] for r in evaluated}):
        if scenario != "A_CONTEXT_DECAY":
            continue

        rows = sorted(
            [r for r in evaluated if r["scenario"] == scenario],
            key=lambda r: int(r["scenario_turn"]),
        )

        depth = 0

        for row in rows:
            if row["probe_type"] != "context_probe":
                continue

            if row["context_correct"] == "PASS":
                try:
                    depth = max(depth, int(row["context_distance"]))
                except Exception:
                    pass
            else:
                break

        result[scenario] = str(depth)

    return result


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()), delimiter=";")
        writer.writeheader()
        writer.writerows(rows)


def write_summary(
    path: Path,
    evaluated: list[dict],
    scenario_summary: list[dict],
) -> None:
    latencies = [
        float(r["latency_ms"])
        for r in evaluated
        if str(r.get("latency_ms", "")).strip()
    ]

    hard_failures = [r for r in evaluated if r["overall_status"] == "FAIL"]
    review = [r for r in evaluated if r["overall_status"] == "REVIEW"]
    retention = observed_retention_depth(evaluated)

    lines = [
        "PECUS CHAIN — Benchmark V2 Summary",
        "=" * 48,
        "",
        f"Run ID: {evaluated[0]['run_id'] if evaluated else 'N/A'}",
        f"Test totali: {len(evaluated)}",
        f"Hard FAIL: {len(hard_failures)}",
        f"REVIEW: {len(review)}",
        "",
        "SCENARIO METRICS",
        "-" * 48,
    ]

    for m in scenario_summary:
        lines.extend(
            [
                f"{m['scenario']}",
                f"  Context accuracy: {m['context_accuracy_pct']}%",
                f"  Scope accuracy: {m['scope_accuracy_pct']}%",
                f"  Animal resolution: {m['animal_resolution_pct']}%",
                f"  Probe success: {m['probe_success_pct']}%",
            ]
        )

    if retention:
        lines.extend(["", "CONTEXT DECAY", "-" * 48])
        for scenario, depth in retention.items():
            lines.append(f"{scenario}: retention depth osservata = {depth} turni")

    if latencies:
        lines.extend(
            [
                "",
                "LATENCY",
                "-" * 48,
                f"Min: {min(latencies):.0f} ms",
                f"Median: {statistics.median(latencies):.0f} ms",
                f"Mean: {statistics.mean(latencies):.0f} ms",
                f"Max: {max(latencies):.0f} ms",
            ]
        )

    lines.extend(["", "FAILURES", "-" * 48])

    if not hard_failures:
        lines.append("Nessun hard failure.")
    else:
        for row in hard_failures:
            lines.append(
                f"{row['test_id']} | {row['scenario']} | turn {row['scenario_turn']} | "
                f"{row['error_type']} | Q: {row['question']}"
            )

    lines.extend(["", "REVIEW", "-" * 48])

    if not review:
        lines.append("Nessuna riga da revisionare.")
    else:
        for row in review:
            lines.append(
                f"{row['test_id']} | {row['scenario']} | turn {row['scenario_turn']} | "
                f"scope={row['detected_scope']} animals={row['detected_animals']}"
            )

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "input",
        nargs="?",
        default="results/benchmark_v2_results.csv",
    )
    parser.add_argument(
        "--output",
        default="results/benchmark_v2_evaluated.csv",
    )
    parser.add_argument(
        "--scenario-output",
        default="results/benchmark_v2_scenarios.csv",
    )
    parser.add_argument(
        "--summary",
        default="results/benchmark_v2_summary.txt",
    )
    args = parser.parse_args()

    input_path = Path(args.input)

    with input_path.open("r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f, delimiter=";"))

    if not rows:
        raise SystemExit("Nessun risultato da valutare.")

    evaluated = evaluate(rows)
    scenarios = scenario_metrics(evaluated)

    write_csv(Path(args.output), evaluated)
    write_csv(Path(args.scenario_output), scenarios)
    write_summary(Path(args.summary), evaluated, scenarios)

    counts = Counter(r["overall_status"] for r in evaluated)

    print("Benchmark valutato:", len(evaluated), "test")
    print(
        "PASS=", counts["PASS"],
        "REVIEW=", counts["REVIEW"],
        "FAIL=", counts["FAIL"],
    )
    print("Output:", args.output)
    print("Scenario metrics:", args.scenario_output)
    print("Summary:", args.summary)


if __name__ == "__main__":
    main()
