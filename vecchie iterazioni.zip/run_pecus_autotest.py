from __future__ import annotations

from playwright.sync_api import sync_playwright
from pathlib import Path
from datetime import datetime
import argparse
import csv
import re
import shutil
import time


DEFAULT_BOT_NAME = "Marica Marches"
DEFAULT_SUITE = Path("tests/pecus_llm_current_suite.csv")

TIMEOUT_SECONDS = 150
QUIET_SECONDS = 6
BETWEEN_QUESTIONS_SECONDS = 5
BETWEEN_AREAS_SECONDS = 8
BETWEEN_REGRESSION_SCENARIOS_SECONDS = 8


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def parse_whatsapp_datetime(metadata: str):
    if not metadata:
        return None
    m = re.search(
        r"\[(\d{1,2}):(\d{2}),\s*(\d{1,2})/(\d{1,2})/(\d{4})\]",
        metadata,
    )
    if not m:
        return None
    hh, mm, dd, mon, yyyy = map(int, m.groups())
    return datetime(yyyy, mon, dd, hh, mm)


def message_key(message: dict) -> str:
    if message.get("message_id"):
        return "id:" + str(message["message_id"])
    return (
        "fallback:"
        + str(message.get("metadata"))
        + "|"
        + normalize_text(message.get("text", ""))[:250]
    )


def get_bot_messages(page, bot_name: str) -> list[dict]:
    locator = page.locator(f'[data-pre-plain-text*="{bot_name}:"]')
    messages = []

    for i in range(locator.count()):
        element = locator.nth(i)
        try:
            text = element.inner_text().strip()
            metadata = element.get_attribute("data-pre-plain-text")

            ancestor = element.locator("xpath=ancestor::*[@data-id][1]")
            message_id = None
            if ancestor.count() > 0:
                message_id = ancestor.get_attribute("data-id")

            if text:
                messages.append(
                    {
                        "message_id": message_id,
                        "metadata": metadata,
                        "message_dt": parse_whatsapp_datetime(metadata),
                        "text": text,
                        "dom_index": i,
                    }
                )
        except Exception:
            pass

    # WhatsApp può mostrare temporaneamente la stessa risposta con e senza data-id.
    deduped = {}
    for m in messages:
        content_key = (
            m["metadata"],
            normalize_text(m["text"])[:220],
        )
        if content_key not in deduped:
            deduped[content_key] = m
        else:
            existing = deduped[content_key]
            if m.get("message_id") and not existing.get("message_id"):
                existing["message_id"] = m["message_id"]
            if len(m["text"]) > len(existing["text"]):
                existing["text"] = m["text"]

    return list(deduped.values())


def expand_message_by_id(page, message_id):
    if not message_id:
        return False
    try:
        node = page.locator(f'[data-id="{message_id}"]')
        if node.count() == 0:
            return False

        more = node.get_by_text("Leggi di più", exact=True)
        if more.count() > 0:
            more.last.click(timeout=3000)
            page.wait_for_timeout(800)
            return True
    except Exception:
        pass
    return False


def load_suite(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return [
            {
                str(k).strip(): str(v).strip() if v is not None else ""
                for k, v in row.items()
            }
            for row in csv.DictReader(f, delimiter=";")
        ]


def select_tests(rows: list[dict], mode: str) -> list[dict]:
    if mode == "smoke":
        selected = [
            r for r in rows
            if r.get("suite_type") == "functional"
            and r.get("variant_type") == "canonical"
        ]
        return sorted(
            selected,
            key=lambda r: (
                int(r.get("area_order") or 0),
                int(r.get("case_order") or 0),
            ),
        )

    if mode == "functional":
        selected = [r for r in rows if r.get("suite_type") == "functional"]
        return sorted(
            selected,
            key=lambda r: int(r.get("execution_order") or 0),
        )

    if mode == "regression":
        selected = [r for r in rows if r.get("suite_type") == "regression"]
        scenario_order = {
            "A_CONTEXT_DECAY": 1,
            "B_SCOPE_RECOVERY": 2,
            "C_ENTITY_SWITCH": 3,
            "D_NOISE_RETENTION": 4,
            "E_PARAPHRASE_PRODUCTION": 5,
        }
        return sorted(
            selected,
            key=lambda r: (
                scenario_order.get(r.get("scenario"), 99),
                int(r.get("scenario_turn") or 0),
            ),
        )

    if mode == "all":
        functional = select_tests(rows, "functional")
        regression = select_tests(rows, "regression")
        return functional + regression

    raise ValueError(f"Mode non supportato: {mode}")


def qualifying_new_messages(
    page,
    bot_name: str,
    known_keys: set[str],
    send_minute: datetime,
) -> list[dict]:
    candidates = []
    for m in get_bot_messages(page, bot_name):
        key = message_key(m)

        if key in known_keys:
            continue

        dt = m.get("message_dt")
        # Blocca messaggi storici riapparsi nel DOM.
        if dt is not None and dt < send_minute:
            continue

        candidates.append(m)

    candidates.sort(
        key=lambda m: (
            m.get("message_dt") or send_minute,
            m.get("dom_index", 0),
        )
    )
    return candidates


def run_single_test(
    page,
    message_box,
    bot_name: str,
    test: dict,
    known_keys: set[str],
):
    print()
    print("=" * 84)
    print(
        f"{test.get('area')} | {test.get('case_id')} | "
        f"{test.get('variant_type')} | {test.get('test_id')}"
    )
    print("Profilo:", test.get("evaluation_profile"))
    print("Domanda:", test.get("question"))
    print("=" * 84)

    # Snapshot globale immediatamente prima dell'invio.
    for m in get_bot_messages(page, bot_name):
        known_keys.add(message_key(m))

    send_dt = datetime.now()
    send_minute = send_dt.replace(second=0, microsecond=0)
    start = time.monotonic()

    message_box.click()
    message_box.fill(test["question"])
    message_box.press("Enter")

    print("Messaggio inviato. Attendo PECUS...")

    deadline = time.monotonic() + TIMEOUT_SECONDS
    first_detection_time = None
    collected = {}

    while time.monotonic() < deadline:
        candidates = qualifying_new_messages(
            page, bot_name, known_keys, send_minute
        )

        if candidates:
            first_detection_time = time.monotonic()
            for m in candidates:
                collected[message_key(m)] = m
            break

        page.wait_for_timeout(500)

    if not collected:
        return {
            "response": "",
            "latency_ms": None,
            "messages": [],
            "truncated": False,
            "success": False,
            "note": "TIMEOUT_ABORT_RUN",
            "send_system_timestamp": send_dt.isoformat(timespec="seconds"),
        }

    latency_ms = int((first_detection_time - start) * 1000)
    print("Prima risposta rilevata dopo:", latency_ms, "ms")

    # Aspetta che WhatsApp stabilizzi data-id.
    page.wait_for_timeout(1200)

    for m in qualifying_new_messages(page, bot_name, known_keys, send_minute):
        collected[message_key(m)] = m

    # Espande solo i messaggi candidati del turno corrente.
    for m in list(collected.values()):
        expand_message_by_id(page, m.get("message_id"))

    last_change = time.monotonic()
    last_keys = set(collected)

    while True:
        page.wait_for_timeout(500)
        current = {
            message_key(m): m
            for m in qualifying_new_messages(
                page, bot_name, known_keys, send_minute
            )
        }
        current_keys = set(current)

        if current_keys != last_keys:
            last_keys = current_keys
            last_change = time.monotonic()

        collected.update(current)

        if time.monotonic() - last_change >= QUIET_SECONDS:
            break

    # Ultimo refresh dopo l'espansione.
    for m in qualifying_new_messages(page, bot_name, known_keys, send_minute):
        collected[message_key(m)] = m

    # Deduplicazione logica finale.
    logical = {}
    for m in collected.values():
        ck = (m["metadata"], normalize_text(m["text"])[:220])
        if ck not in logical:
            logical[ck] = m
        else:
            existing = logical[ck]
            if m.get("message_id") and not existing.get("message_id"):
                existing["message_id"] = m["message_id"]
            if len(m["text"]) > len(existing["text"]):
                existing["text"] = m["text"]

    final_messages = sorted(
        logical.values(),
        key=lambda m: (
            m.get("message_dt") or send_minute,
            m.get("dom_index", 0),
        ),
    )

    response = "\n\n".join(
        m["text"].strip()
        for m in final_messages
    )
    truncated = "Leggi di più" in response

    for m in final_messages:
        known_keys.add(message_key(m))

    success = bool(final_messages and response.strip())
    note = "OK" if success else "EMPTY_FINAL_RESPONSE"

    print()
    print("--- RISPOSTA PECUS ---")
    print(response)
    print("-----------------------")
    print("Messaggi logici:", len(final_messages))
    print("Troncata:", truncated)

    return {
        "response": response,
        "latency_ms": latency_ms,
        "messages": final_messages,
        "truncated": truncated,
        "success": success,
        "note": note,
        "send_system_timestamp": send_dt.isoformat(timespec="seconds"),
    }


RAW_BASE_FIELDS = [
    "run_id",
    "run_mode",
    "sequence_no",
    "test_id",
    "case_id",
    "area",
    "suite_type",
    "scenario",
    "scenario_turn",
    "block",
    "variant_index",
    "variant_type",
    "variant_source",
    "previously_executed",
    "prior_validated",
    "prior_result",
    "source_case_id",
    "source_mapping",
    "question",
    "evaluation_profile",
    "expected_scope",
    "expected_animal",
    "input_data",
    "expected_behavior",
    "expected_fields",
    "fallback",
    "guardrail",
    "support_current",
    "probe_type",
    "response",
    "latency_ms",
    "message_count",
    "response_truncated",
    "message_ids",
    "whatsapp_metadata",
    "send_system_timestamp",
    "system_timestamp",
    "collector_success",
    "collector_note",
]


def append_raw(path: Path, run_id: str, run_mode: str, seq: int, test: dict, result: dict):
    exists = path.exists()

    row = {
        "run_id": run_id,
        "run_mode": run_mode,
        "sequence_no": seq,
    }

    for field in RAW_BASE_FIELDS:
        if field in test:
            row[field] = test[field]

    row.update(
        {
            "response": result["response"],
            "latency_ms": "" if result["latency_ms"] is None else result["latency_ms"],
            "message_count": len(result["messages"]),
            "response_truncated": result["truncated"],
            "message_ids": " | ".join(
                str(m.get("message_id")) for m in result["messages"]
            ),
            "whatsapp_metadata": " | ".join(
                str(m.get("metadata")) for m in result["messages"]
            ),
            "send_system_timestamp": result["send_system_timestamp"],
            "system_timestamp": datetime.now().isoformat(timespec="seconds"),
            "collector_success": result["success"],
            "collector_note": result["note"],
        }
    )

    with path.open("a", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=RAW_BASE_FIELDS,
            delimiter=";",
            extrasaction="ignore",
        )
        if not exists:
            writer.writeheader()
        writer.writerow({k: row.get(k, "") for k in RAW_BASE_FIELDS})


def maybe_evaluate(raw_path: Path, run_dir: Path):
    try:
        from evaluate_pecus_autotest import evaluate_file

        result = evaluate_file(raw_path, run_dir)
        print()
        print("=" * 84)
        print("VALUTAZIONE AUTOMATICA COMPLETATA")
        print("=" * 84)
        print("Evaluated:", result["evaluated"])
        print("Area summary:", result["area_summary"])
        print("Consistency:", result["consistency"])
        print("Summary:", result["summary"])
    except Exception as exc:
        print()
        print("ATTENZIONE: raccolta salvata, ma valutazione automatica non completata.")
        print("Errore evaluator:", repr(exc))
        print("Puoi rilanciare manualmente:")
        print(f'py evaluate_pecus_autotest.py "{raw_path}"')


def main():
    parser = argparse.ArgumentParser(
        description="PECUS CHAIN — runner WhatsApp per il current LLM question set."
    )
    parser.add_argument(
        "--mode",
        choices=["smoke", "functional", "regression", "all"],
        default="smoke",
        help=(
            "smoke=27 canoniche; functional=canoniche+parafrasi; "
            "regression=V3; all=functional+regression"
        ),
    )
    parser.add_argument(
        "--suite",
        default=str(DEFAULT_SUITE),
        help="Percorso pecus_llm_current_suite.csv",
    )
    parser.add_argument(
        "--bot-name",
        default=DEFAULT_BOT_NAME,
        help="Nome mittente PECUS nel metadata WhatsApp.",
    )
    args = parser.parse_args()

    suite_path = Path(args.suite)

    if not suite_path.exists():
        raise SystemExit(
            f"Suite non trovata: {suite_path}\n"
            "Copia pecus_llm_current_suite.csv dentro tests/ oppure usa --suite."
        )

    rows = load_suite(suite_path)
    tests = select_tests(rows, args.mode)

    if not tests:
        raise SystemExit("Nessun test selezionato.")

    run_id = "AUTO_" + datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = Path("results") / run_id
    run_dir.mkdir(parents=True, exist_ok=False)

    raw_path = run_dir / "raw_results.csv"
    suite_snapshot = run_dir / "suite_snapshot.csv"
    shutil.copy2(suite_path, suite_snapshot)

    print("PECUS LLM AUTOTEST")
    print("Run ID:", run_id)
    print("Mode:", args.mode)
    print("Test selezionati:", len(tests))
    print("Output:", run_dir)

    with sync_playwright() as p:
        context = p.chromium.launch_persistent_context(
            user_data_dir="./whatsapp_profile",
            headless=False,
        )

        page = context.pages[0]

        if not page.url.startswith("https://web.whatsapp.com"):
            page.goto("https://web.whatsapp.com")

        page.wait_for_timeout(5000)

        message_box = page.locator(
            '[contenteditable="true"][role="textbox"][data-tab="10"]'
        )
        message_box.wait_for(state="visible", timeout=30000)

        print("WhatsApp pronto.")
        print("Composer:", message_box.get_attribute("aria-label"))

        known_keys = {
            message_key(m)
            for m in get_bot_messages(page, args.bot_name)
        }

        previous_area = None
        previous_scenario = None

        for seq, test in enumerate(tests, start=1):
            area = test.get("area")
            scenario = test.get("scenario")

            if previous_area and area != previous_area:
                print()
                print("#" * 84)
                print("NUOVA AREA:", area)
                print("#" * 84)
                page.wait_for_timeout(BETWEEN_AREAS_SECONDS * 1000)

            if (
                test.get("suite_type") == "regression"
                and previous_scenario
                and scenario != previous_scenario
            ):
                print()
                print("#" * 84)
                print("NUOVO SCENARIO REGRESSION:", scenario)
                print("#" * 84)
                page.wait_for_timeout(
                    BETWEEN_REGRESSION_SCENARIOS_SECONDS * 1000
                )

            result = run_single_test(
                page,
                message_box,
                args.bot_name,
                test,
                known_keys,
            )

            append_raw(
                raw_path,
                run_id,
                args.mode,
                seq,
                test,
                result,
            )

            print(f"Salvato {seq}/{len(tests)}")

            if not result["success"]:
                print()
                print(
                    "RUN INTERROTTO: timeout/risposta vuota. "
                    "Questo protegge l'allineamento domanda→risposta."
                )
                print("Ultimo test:", test.get("test_id"))
                print("Raw parziale:", raw_path)
                break

            previous_area = area
            previous_scenario = scenario

            if seq < len(tests):
                page.wait_for_timeout(
                    BETWEEN_QUESTIONS_SECONDS * 1000
                )

        context.close()

    # Valuta anche run parziali: l'integrità collector resta visibile.
    maybe_evaluate(raw_path, run_dir)

    print()
    print("Run terminato.")
    print("Cartella:", run_dir)
    print("Raw:", raw_path)


if __name__ == "__main__":
    main()
